export interface IContact{
    id:number,
    name:string,
    email:string
}