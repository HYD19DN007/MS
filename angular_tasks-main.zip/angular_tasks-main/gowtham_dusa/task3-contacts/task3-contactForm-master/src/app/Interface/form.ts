export class Form{
    id:number | any;
    name:string | any;
    email:string | any;
    
  }