import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scorboard',
  templateUrl: './scorboard.component.html',
  styleUrls: ['./scorboard.component.css']
})
export class ScorboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
