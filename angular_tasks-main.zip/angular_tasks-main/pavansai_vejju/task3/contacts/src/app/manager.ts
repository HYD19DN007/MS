export   class Manager

  
        {  Manager_name: String |any;
        mail_id:String |any;}
    



