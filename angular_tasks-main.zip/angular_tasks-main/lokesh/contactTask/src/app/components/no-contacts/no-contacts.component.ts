import { Component } from '@angular/core';

@Component({
  selector: 'app-no-contacts',
  templateUrl: './no-contacts.component.html',
  styleUrls: ['./no-contacts.component.css']
})
export class NoContactsComponent {
}
