export interface IContact {
    firstname: string,
      lastname: string,
      email: string,
      text: string,
      image: string,
      id: number
}



export interface IBackgroundStyle {
  backgroundImage: string
}