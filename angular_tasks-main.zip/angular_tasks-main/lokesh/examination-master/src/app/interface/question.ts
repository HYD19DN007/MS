export interface IQuestions{
    id: number
    question:string,
    options:string[],
    answer:string
}