package Examples.Demo.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class HDept {
	@Id
	private int deptid;
	@Column(length = 30)
	private String dname;
	public HDept() {
		super();
	}

	public HDept(int deptid, String dname) {
		super();
		this.deptid = deptid;
		this.dname = dname;
	}

	public int getDeptid() {
		return deptid;
	}

	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}
}
