package Examples.Demo.Pojo;

import java.time.LocalDate;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Emp_Dept {
	@EmbeddedId
	private EmpDeptComposite empdept;
	private LocalDate endDate;

	public EmpDeptComposite getEmpdept() {
		return empdept;
	}

	public void setEmpdept(EmpDeptComposite empdept) {
		this.empdept = empdept;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}


	public Emp_Dept() {
		super();
	}

	public Emp_Dept(EmpDeptComposite empdept, LocalDate endDate) {
		super();
		this.empdept = empdept;
		this.endDate = endDate;
	}

}
