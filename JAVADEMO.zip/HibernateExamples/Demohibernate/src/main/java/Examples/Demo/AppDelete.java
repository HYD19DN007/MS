package Examples.Demo;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import Examples.Demo.Pojo.Vendor;

/**
 * Hello world!
 *
 */
public class AppDelete 
{
    public static void main( String[] args )
    {
    	Session S=SessionFactoryCls.getSessionobj();
    	Vendor V=new Vendor(2L,"RAM",LocalDate.parse("2023-10-22"),6000);
    	Transaction T=S.beginTransaction();
    	S.save(V);
    	T.commit();
    	S.close();
    	
    }
}
