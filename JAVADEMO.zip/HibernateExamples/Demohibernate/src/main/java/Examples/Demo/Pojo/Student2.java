package Examples.Demo.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Student2 {
	@Id
	private int studId;
	@Column(length = 30)
	private String studentName;
	
	public Student2() {
		super();
	}

	public Student2(int studId, String studentName) {
		super();
		this.studId = studId;
		this.studentName = studentName;
	}

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	
}
