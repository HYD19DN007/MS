package Examples.Demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SessionFactoryCls {
	public static Session getSessionobj()
	{
		Configuration cfg=new Configuration().configure("Examples/Demo/myhibernate.cfg.xml");
    	SessionFactory F=cfg.buildSessionFactory();
    	Session S=F.openSession();
    
    	return S;
    
		
	}

}
