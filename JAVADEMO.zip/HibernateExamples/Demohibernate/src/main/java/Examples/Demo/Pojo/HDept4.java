package Examples.Demo.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class HDept4 {
	@Id
	private int deptId;
	@Column(length = 30)
	private String dname;

	public HDept4() {
		super();
	}

	public HDept4(int deptId, String dname) {
		super();
		this.deptId = deptId;
		this.dname = dname;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}
}
