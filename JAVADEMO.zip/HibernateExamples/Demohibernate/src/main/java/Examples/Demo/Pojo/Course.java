package Examples.Demo.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Course {
	@Id
	private int courseid;
	@Column(length = 30)
	private String courseName;

	public Course() {
		super();
	}

	public Course(int courseid, String courseName) {
		super();
		this.courseid = courseid;
		this.courseName = courseName;
	}

	public int getCourseid() {
		return courseid;
	}

	public void setCourseid(int courseid) {
		this.courseid = courseid;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

}
