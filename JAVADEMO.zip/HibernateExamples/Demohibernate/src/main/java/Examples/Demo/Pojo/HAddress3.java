package Examples.Demo.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class HAddress3 {
	@Id
	private int addressId;

	@Column(length = 30)
	private String Hno;
	@Column(length = 30)
	private String City;
	@Column(length = 30)
	private String Pincode;

	
	public HAddress3() {
		super();
	}
	public HAddress3(int addressId, String hno, String city, String pincode) {
		super();
		this.addressId = addressId;
		Hno = hno;
		City = city;
		Pincode = pincode;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getHno() {
		return Hno;
	}
	public void setHno(String hno) {
		Hno = hno;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getPincode() {
		return Pincode;
	}
	public void setPincode(String pincode) {
		Pincode = pincode;
	}
}
