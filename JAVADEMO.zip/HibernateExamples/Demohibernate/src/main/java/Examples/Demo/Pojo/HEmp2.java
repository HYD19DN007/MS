package Examples.Demo.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class HEmp2 {
	@Id
	private int empId;
	@Column(length = 30)
	private String ename;

	
	public HEmp2() {
		super();
	}
	public HEmp2(int empId, String ename) {
		super();
		this.empId = empId;
		this.ename = ename;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	
}
