package Examples.Demo.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class HEmp3 {
	@Id
	private int empId;
	@Column(length = 30)
	private String ename;

	@OneToOne
	@JoinColumn(name = "deptid")
	private HDept dept;

	
	@OneToOne
	@JoinColumn(name="addressId",unique = true)
	private HAddress3 address;
	
	
	public HEmp3() {
		super();
	}

	
	public HAddress3 getAddress() {
		return address;
	}


	public void setAddress(HAddress3 address) {
		this.address = address;
	}


	public HEmp3(int empId, String ename, HDept dept, HAddress3 address) {
		super();
		this.empId = empId;
		this.ename = ename;
		this.dept = dept;
		this.address = address;
	}


	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public HDept getDept() {
		return dept;
	}

	public void setDept(HDept dept) {
		this.dept = dept;
	}

}
