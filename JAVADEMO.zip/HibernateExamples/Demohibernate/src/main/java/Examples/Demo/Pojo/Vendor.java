package Examples.Demo.Pojo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "tblvendor")
public class Vendor {
	@Id
	private Long id;
	@Column(length = 30,name = "vname",nullable = false,unique = true)
	public String vendorName;
	@Column(name="regdate")
	private LocalDate registrationDate;
	private double fees;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public LocalDate getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}

	public Vendor() {}
	public Vendor(Long id, String vendorName, LocalDate registrationDate, double fees) {
		super();
		this.id=id;
		this.vendorName = vendorName;
		this.registrationDate = registrationDate;
		this.fees = fees;
	}
	
}
