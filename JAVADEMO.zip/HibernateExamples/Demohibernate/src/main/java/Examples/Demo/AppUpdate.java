package Examples.Demo;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import Examples.Demo.Pojo.Vendor;


/**
 * Hello world!
 *
 */
public class AppUpdate 
{
    public static void main( String[] args )
    {
    	//Session S=null;
//    	try {
//    	S=SessionFactoryCls.getSessionobj();
//    	Vendor V=S.load(Vendor.class, 9L);
//    	System.out.println(V);
//    	System.out.println(V.getVendorName()+ " "+ V.getRegistrationDate()+ " "+V.getFees());
//    	Transaction T=S.beginTransaction();
//    	V.setFees(14000);
//    	V.setVendorName("ABC Company");
//    	S.update(V);
//    	T.commit();
//    
//    	}
//    	catch(ObjectNotFoundException E)
//    	{
//    		System.out.println("No Vendor Exists");
//    	}
//    	finally {
//			S.close();
//		}
   	
    	Session S=null;
    	S=SessionFactoryCls.getSessionobj();
    	Vendor V=S.get(Vendor.class, 2L);// When we use get Method if Id is not existing then it returns null
    	//When we use load method id id is not existing it will throw exception "objectNotFoundException"
    	if(V!=null)
    	{
    	
    	System.out.println(V.getVendorName()+ " "+ V.getRegistrationDate()+ " "+V.getFees());
    	Transaction T=S.beginTransaction();
    	V.setFees(44000);
    	V.setVendorName("ABC Company");
    	S.update(V);
    	T.commit();
    	S.close();
    	}
    	else
    	{
    		System.out.println("NO vendor exists");
    	}
    	
    	
    }
}
