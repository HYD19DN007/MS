package Examples.Demo.Pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity
public class HDept2 {
	@Id
	private int deptid;
	@Column(length = 30)
	private String dname;
	@OneToMany
	@JoinColumn(name="deptid")
	private List<HEmp2> emps;

	public HDept2() {
		super();
	}
	public HDept2(int deptid, String dname, List<HEmp2> emps) {
		super();
		this.deptid = deptid;
		this.dname = dname;
		this.emps = emps;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public List<HEmp2> getEmps() {
		return emps;
	}
	public void setEmps(List<HEmp2> emps) {
		this.emps = emps;
	}
	
	

	}
