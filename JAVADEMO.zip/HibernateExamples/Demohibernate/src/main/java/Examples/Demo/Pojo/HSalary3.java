package Examples.Demo.Pojo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class HSalary3 implements Serializable{
	@Id
	@OneToOne
	@JoinColumn(name = "empId")
	private HEmp3 emp;
	private int basic;

	public HSalary3() {
	}

	public HSalary3(HEmp3 emp, int basic) {
		super();
		this.emp = emp;
		this.basic = basic;
	}

	public HEmp3 getEmp() {
		return emp;
	}

	public void setEmp(HEmp3 emp) {
		this.emp = emp;
	}

	public int getBasic() {
		return basic;
	}

	public void setBasic(int basic) {
		this.basic = basic;
	}

}
