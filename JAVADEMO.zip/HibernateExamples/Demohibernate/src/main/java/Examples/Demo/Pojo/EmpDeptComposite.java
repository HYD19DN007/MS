package Examples.Demo.Pojo;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Embeddable//create a composite
public class EmpDeptComposite implements Serializable{

	@OneToOne
	@JoinColumn(name="empId")
	private HEmp4 emp;
	
	@OneToOne
	@JoinColumn(name="deptId")
	private HDept4 dept;
	
	private LocalDate startDate;
	
	public EmpDeptComposite() {
		super();
	}

	public EmpDeptComposite(HEmp4 emp, HDept4 dept, LocalDate startDate) {
		super();
		this.emp = emp;
		this.dept = dept;
		this.startDate = startDate;
	}

	public HEmp4 getEmp() {
		return emp;
	}

	public void setEmp(HEmp4 emp) {
		this.emp = emp;
	}

	public HDept4 getDept() {
		return dept;
	}

	public void setDept(HDept4 dept) {
		this.dept = dept;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	
}
