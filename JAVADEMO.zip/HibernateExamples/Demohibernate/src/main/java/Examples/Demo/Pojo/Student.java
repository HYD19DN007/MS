package Examples.Demo.Pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Student {
	@Id
	private int studId;
	@Column(length = 30)
	private String studentName;
	@OneToOne
	@JoinColumn(name = "courseId")
	private Course course;

	public Student() {
		super();
	}

	public Student(int studId, String studentName, Course course) {
		super();
		this.studId = studId;
		this.studentName = studentName;
		this.course = course;
	}

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

}
