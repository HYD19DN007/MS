package Examples.Demo.Pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Course2 {
	@Id
	private int courseid;
	@Column(length = 30)
	private String courseName;
	@OneToMany
	@JoinColumn(name="courseid")
	private List<Student2> student;
	
	
	public Course2() {
		super();
	}

	public Course2(int courseid, String courseName,List<Student2> st) {
		super();
		this.courseid = courseid;
		this.courseName = courseName;
		this.student=st;
	}

	public int getCourseid() {
		return courseid;
	}

	public void setCourseid(int courseid) {
		this.courseid = courseid;
	}

	public List<Student2> getStudent() {
		return student;
	}

	public void setStudent(List<Student2> student) {
		this.student = student;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

}
