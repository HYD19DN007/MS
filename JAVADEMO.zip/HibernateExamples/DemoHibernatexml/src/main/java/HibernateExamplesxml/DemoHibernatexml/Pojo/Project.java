package HibernateExamplesxml.DemoHibernatexml.Pojo;

import java.time.LocalDate;

public class Project {
	private int projectId;
	private String projectName;
	private LocalDate startDate;
	private double duration;

	public Project() {
		super();
	}

	public Project(int projectId, String projectName, LocalDate startDate, double duration) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.startDate = startDate;
		this.duration = duration;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

}
