package HibernateExamplesxml.DemoHibernatexml;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import HibernateExamplesxml.DemoHibernatexml.Pojo.Project;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Configuration cfg=new Configuration().configure("HibernateExamplesxml/DemoHibernatexml/myhibernate.cfg.xml");
    	SessionFactory F=cfg.buildSessionFactory();
    	//step2
    	Session S=F.openSession();
    	Project P=new Project(1,"HMS",LocalDate.parse("2024-09-01"),90);
    	Transaction T=S.beginTransaction();
    	S.save(P);
    	T.commit();
    	S.close();
    	F.close();  
    
    }
}
