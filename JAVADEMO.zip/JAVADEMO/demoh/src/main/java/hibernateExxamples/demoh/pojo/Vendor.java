package hibernateExxamples.demoh.pojo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblVendor")
public class Vendor {
	@Id
	private int vendorId;
	
	private String vendorName;
	@Column(name = "regDate", length = 30)
	private LocalDate registrationDate;
	private int registrationFees;
	public Vendor() {
		super();
	}
	
	public Vendor(int vendorId, String vendorName, LocalDate registrationDate, int registrationFees) {
		super();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.registrationDate = registrationDate;
		this.registrationFees = registrationFees;
	}
	
	public int getVendorId() {
		return vendorId;
	}
	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public LocalDate getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}
	public int getRegistrationFees() {
		return registrationFees;
	}
	public void setRegistrationFees(int registrationFees) {
		this.registrationFees = registrationFees;
	}
	
}



