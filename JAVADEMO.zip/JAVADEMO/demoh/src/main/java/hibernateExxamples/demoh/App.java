package hibernateExxamples.demoh;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import hibernateExxamples.demoh.pojo.Vendor;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Configuration Cfg=new Configuration().configure("hibernateExxamples/demoh/hibernate.cfg.xml");  

    	SessionFactory factory=Cfg.buildSessionFactory();

    	
    	//SessionFactory factory=SessionFactoryCls.getSessionFactory();

    	Session S=factory.openSession();

    	Vendor V=new Vendor(11, "ABCD", LocalDate.parse("2002-09-09"), 10000);

    	

    	Transaction T=S.beginTransaction();

    	S.save(V);

    	T.commit();

    	S.close();

    	factory.close();
    }
}
