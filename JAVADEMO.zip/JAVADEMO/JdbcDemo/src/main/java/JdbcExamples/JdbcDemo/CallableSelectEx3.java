package JdbcExamples.JdbcDemo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.OracleTypes;

public class CallableSelectEx3 {
public static void main(String[] args) {

	Connection Con=null;
	CallableStatement Cstmt=null;
	
	//Step 1
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage()+ " Driver Error");
	}
	
	//Step 2  2.	Create Connection Object
	
	try {
		Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println("Connection Error"+ e.getMessage());
	}
	try {
		Cstmt =Con.prepareCall("{call sp_extract(?)}");
		Cstmt.registerOutParameter(1, OracleTypes.CURSOR);
		Cstmt.execute();
		ResultSet R=(ResultSet) Cstmt.getObject(1);
		while(R.next())
		{
			System.out.println(R.getInt(1)+ " "+ R.getString(2));
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		try {
			Con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
}
