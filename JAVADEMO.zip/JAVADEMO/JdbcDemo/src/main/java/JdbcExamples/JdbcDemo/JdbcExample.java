package JdbcExamples.JdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class JdbcExample {
	public static void main(String[] args) {
		Connection Con=null;
		Statement Stmt=null;
		Scanner S=new Scanner(System.in);
		System.out.println("Enter the details");
		int eno=S.nextInt();
		S.nextLine();
		String en=S.nextLine();
		String g=S.nextLine();
		String d=S.nextLine();
		DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		
		LocalDate db=LocalDate.parse(d,D);
		String email=S.nextLine();
		int dno=S.nextInt();
		
		
		
		
		//Step 1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage()+ " Driver Error");
		}
		
		//Step 2  2.	Create Connection Object
		
		try {
			Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error"+ e.getMessage());
		}
		
		//Step 3 	Create a statement
		
		try {
			Stmt=Con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Statement Error");
		}
		
		
				
		//Step 4
		
		try {
			int R=Stmt.executeUpdate("insert into Employee values("+eno+",'"+en+"','"+g+"','"+D.format(db)+"','"+email+"',"+dno+")");
			
			if(R==1)
				System.out.println("1 Row inserted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		System.out.println("SQL Query Error"+e.getMessage());
		}
		
		
		//step 5
		try {
			Con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Could not close "+e.getMessage());
		}
		
	}
}
