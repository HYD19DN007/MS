package JdbcExamples.JdbcDemo.PL;

import java.util.Scanner;

import JdbcExamples.JdbcDemo.BL.Emp;
import JdbcExamples.JdbcDemo.BL.EmpBl;

public class JdbcInsert {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	System.out.println("enter details");
	int empno=S.nextInt();
	S.nextLine();
	String ename=S.nextLine();
	String job=S.nextLine();
	int mgr=S.nextInt();
	S.nextLine();
	String hiredate=S.nextLine();
	int sal=S.nextInt();
	int comm=S.nextInt();
	int deptno=S.nextInt();
	Emp E=new Emp(empno,ename,job,mgr,hiredate,sal,comm,deptno);
	EmpBl EB=new EmpBl();
	String Str=EB.insertEmp(E);
	System.out.println(Str);
}
}
