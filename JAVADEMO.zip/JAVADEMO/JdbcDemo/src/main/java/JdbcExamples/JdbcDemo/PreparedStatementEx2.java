package JdbcExamples.JdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PreparedStatementEx2 {
public static void main(String[] args) {

	Connection Con=null;
	PreparedStatement Pstmt=null;
	Scanner S=new Scanner(System.in);
	System.out.println("Enter the details");
	int eno=S.nextInt();
	S.nextLine();
	String email=S.nextLine();
	int dno=S.nextInt();
	
	
	
	
	//Step 1
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage()+ " Driver Error");
	}
	
	//Step 2 	Create Connection Object
	
	try {
		Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println("Connection Error"+ e.getMessage());
	}
	
	//Step3 
	try {
		Pstmt=Con.prepareStatement("update employee set email=?,deptno=? where empno=?");
		Pstmt.setInt(3, eno);
		Pstmt.setString(1, email);
		Pstmt.setInt(2, dno);
	//step4
		int R=Pstmt.executeUpdate();
		System.out.println(R + " rows inserted");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
	}
	try {
		Con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
