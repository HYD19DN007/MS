package JdbcExamples.JdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcExample2 {
	public static void main(String[] args) {

		Connection Con=null;
		Statement Stmt=null;
		
	//Step 1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver error" +e.getMessage());
		}
		
		//Step 2
		try {
			Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error"+ e.getMessage());
		}
		//Step 3
		try {
			Stmt=Con.createStatement();
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		System.out.println("stetment Error");
		}
		
		//Step 4
		try {
			ResultSet R=Stmt.executeQuery("Select * from employee");
			while(R.next())
			{
				System.out.println(R.getInt(1)+" "+ R.getString(2)+" "+R.getString("gender")+" " + R.getDate("Dob"));
				
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		//Step 5
		try {
			Con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
