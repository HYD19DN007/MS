package JdbcExamples.JdbcDemo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

public class CallableSelectEx1 {
	public static void main(String[] args) {

		Connection Con = null;
		CallableStatement Cstmt = null;
		Scanner S = new Scanner(System.in);
		// Step 1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + " Driver Error");
		}

		// Step 2 2. Create Connection Object

		try {
			Con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error" + e.getMessage());
		}
		try {
			Cstmt = Con.prepareCall("{call sp_extractwithJoins(?)}");
			Cstmt.registerOutParameter(1, OracleTypes.CURSOR);
			Cstmt.execute();
			ResultSet R = (ResultSet) Cstmt.getObject(1);
			if (!R.next()) {
				System.out.println("No data exists");
			} else {
				do {
					System.out.println(R.getInt(1) + " " + R.getString(2)+ " "+ R.getString(3)+" "+R.getString(4));
				} while (R.next());
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				Con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
