package JdbcExamples.JdbcDemo.PL;

import java.util.ArrayList;

import JdbcExamples.JdbcDemo.BL.EmpBl;
import JdbcExamples.JdbcDemo.BL.Report1;
import JdbcExamples.JdbcDemo.BL.Report2;

public class JdbcExtract {
public static void main(String[] args) {
	EmpBl Eb=new EmpBl();
	ArrayList<Report2> list=Eb.getSummary2();
	for (Report2 report2 : list) {
		System.out.println(report2.getJob()+ " "+ report2.getTotal());
	}
}

}
