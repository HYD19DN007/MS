package JdbcExamples.JdbcDemo.BL;

import java.time.LocalDate;
//POJO class
public class Emp2 {

	private Integer empno;
	private String ename;
	private String job;
	private Integer mgr;
	private LocalDate hiredate;
	private Integer sal;
	private Integer comm;
	private Integer deptno;

	public Emp2() {
	}

	public Emp2(Integer empno, String ename, String job, Integer mgr, LocalDate hiredate, Integer sal, Integer comm,
			Integer deptno) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.job = job;
		this.mgr = mgr;
		this.hiredate = hiredate;
		this.sal = sal;
		this.comm = comm;
		this.deptno = deptno;
	}

	public Integer getEmpno() {
		return empno;
	}

	public String getEname() {
		return ename;
	}

	public String getJob() {
		return job;
	}

	public Integer getMgr() {
		return mgr;
	}

	public LocalDate getHiredate() {
		return hiredate;
	}

	public Integer getSal() {
		return sal;
	}

	public Integer getComm() {
		return comm;
	}

	public Integer getDeptno() {
		return deptno;
	}
}
