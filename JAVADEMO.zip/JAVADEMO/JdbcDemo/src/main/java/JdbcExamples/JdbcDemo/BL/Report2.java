package JdbcExamples.JdbcDemo.BL;

public class Report2 {
private String job;
public Report2(String job, Integer total) {
	super();
	this.job = job;
	this.total = total;
}
private Integer total;
public String getJob() {
	return job;
}
public Integer getTotal() {
	return total;
}
public Report2() {}
}
