package JdbcExamples.JdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PreparedStatementEx1 {
public static void main(String[] args) {

	Connection Con=null;
	PreparedStatement Pstmt=null;
	Scanner S=new Scanner(System.in);
	System.out.println("Enter the details");
	int eno=S.nextInt();
	S.nextLine();
	String en=S.nextLine();
	String g=S.nextLine();
	String d=S.nextLine();
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	LocalDate db=LocalDate.parse(d,D);
	String email=S.nextLine();
	int dno=S.nextInt();
	
	
	
	
	//Step 1
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage()+ " Driver Error");
	}
	
	//Step 2 	Create Connection Object
	
	try {
		Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println("Connection Error"+ e.getMessage());
	}
	
	//Step3 
	try {
		Pstmt=Con.prepareStatement("insert into employee values(?,?,?,?,?,?)");
		Pstmt.setInt(1, eno);
		Pstmt.setString(2, en);
		Pstmt.setString(3, g);
		Pstmt.setString(4, db.format(D));
		Pstmt.setString(5, email);
		Pstmt.setInt(6, dno);
	//step4
		int R=Pstmt.executeUpdate();
		System.out.println(R + " rows inserted");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
	}
	try {
		Con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
