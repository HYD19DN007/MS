package JdbcExamples.JdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PreparedStatementEx3 {
public static void main(String[] args) {

	Connection Con=null;
	PreparedStatement Pstmt=null;
	Scanner S=new Scanner(System.in);
	System.out.println("Enter the details");
	int dno=S.nextInt();
	
	
	
	
	//Step 1
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage()+ " Driver Error");
	}
	
	//Step 2 	Create Connection Object
	
	try {
		Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println("Connection Error"+ e.getMessage());
	}
	
	//Step3 
	try {
		Pstmt=Con.prepareStatement("select * from employee where deptno=?");
		Pstmt.setInt(1, dno);
	//step4
		ResultSet R=Pstmt.executeQuery();
		if(!R.next())
		{
			System.out.println("No records with this dept exists");
		}
		else
		{
		do	{
			System.out.println(R.getInt(1)+" "+ R.getString(2)+" "+R.getString("gender")+" " + R.getDate("Dob"));
			
		}while(R.next());
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
	}
	try {
		Con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
