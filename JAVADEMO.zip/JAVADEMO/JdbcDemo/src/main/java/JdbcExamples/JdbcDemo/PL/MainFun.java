package JdbcExamples.JdbcDemo.PL;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import JdbcExamples.JdbcDemo.BL.Emp;
import JdbcExamples.JdbcDemo.BL.EmpBl;

public class MainFun {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	System.out.println("Enter Deptno");
	int dno=S.nextInt();
	EmpBl E=new EmpBl();
	ArrayList<Emp> R=E.getData(dno);
	for (Emp emp : R) {
		System.out.println(emp.getEmpno()+ " "+ emp.getEname()+" " +emp.getJob()+" "+emp.getMgr()+ " "+emp.getHiredate()+ " "+emp.getSal()+ " "+emp.getComm()+ " "+emp.getDeptno());
	}
}


}
