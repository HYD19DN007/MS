package JdbcExamples.JdbcDemo;

import java.util.Scanner;

public class Example {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	System.out.println("Enter");
	String str=S.nextLine();
	String query="Select * from Employee where empno="+str;
	System.out.println(query);
	
}
}
