package JdbcExamples.JdbcDemo.PL;

import java.util.Scanner;

import JdbcExamples.JdbcDemo.BL.Emp;
import JdbcExamples.JdbcDemo.BL.EmpBl;
import JdbcExamples.JdbcDemo.BL.Employee;

public class JdbcInsert2 {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	System.out.println("enter details");
	int empno=S.nextInt();
	S.nextLine();
	String ename=S.nextLine();
	String gender=S.nextLine();
	String dob=S.nextLine();
	String email=S.nextLine();
	int deptno=S.nextInt();
	
	Employee E=new Employee(empno,ename,gender,dob,email,deptno);
	EmpBl EB=new EmpBl();
	String Str=EB.insertEmployee(E);
	
	System.out.println(Str);
}
}
