package JdbcExamples.JdbcDemo.BL;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;

import JdbcExamples.JdbcDemo.DL.DBOperations;

public class EmpBl {

	public ArrayList<Emp> getData(int dno)
	{
		ArrayList<Emp> R= DBOperations.getDetails(dno);
		return R;
	}
	public String   insertEmp(Emp E)
	{
	String S=	DBOperations.insertEmp(E);
	return S;
	}
	
	public String   insertEmployee(Employee E)
	{
	String S=	DBOperations.insertEmployee(E);
	return S;
	}
	public String   insertEmpDate(Emp2 E)
	{
	String S=	DBOperations.insertEmp2(E);
	return S;
	}
	public ArrayList<Report1>   extractdname()
	{
	ArrayList<Report1> S=	DBOperations.extractJoins();
	return S;
	}
	
	public Map<String,Integer>getSummary()
	{
		return DBOperations.getSummary();
	}
	public ArrayList<Report2> getSummary2()
	{
		return DBOperations.getSummary2();
	}
	
}
