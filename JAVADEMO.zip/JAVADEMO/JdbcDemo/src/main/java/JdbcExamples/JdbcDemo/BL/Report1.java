package JdbcExamples.JdbcDemo.BL;

public class Report1 {
private Integer empno;
private String ename;
private String job;
private String dname;

public Integer getEmpno() {
	return empno;
}
public String getEname() {
	return ename;
}
public String getJob() {
	return job;
}
public String getDname() {
	return dname;
}public Report1() {}
public Report1(Integer empno, String ename, String job, String dname) {
	super();
	this.empno = empno;
	this.ename = ename;
	this.job = job;
	this.dname = dname;
}

}
