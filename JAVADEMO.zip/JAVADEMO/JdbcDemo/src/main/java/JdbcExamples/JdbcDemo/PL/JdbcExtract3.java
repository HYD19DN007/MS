package JdbcExamples.JdbcDemo.PL;

import java.util.ArrayList;

import JdbcExamples.JdbcDemo.BL.EmpBl;
import JdbcExamples.JdbcDemo.BL.Report1;

public class JdbcExtract3 {
public static void main(String[] args) {
	EmpBl Eb=new EmpBl();
	ArrayList<Report1> list=Eb.extractdname();
	for (Report1 report1 : list) {
		System.out.println(report1.getEmpno()+ " "+ report1.getEname()+ " "+report1.getJob()+ " "+report1.getDname());
	}
}

}
