package JdbcExamples.JdbcDemo.PL;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import JdbcExamples.JdbcDemo.BL.EmpBl;

public class JdbcExtract2 {
public static void main(String[] args) {
	EmpBl Eb=new EmpBl();
	Map<String,Integer>map= Eb.getSummary();
	Set set = map.entrySet();
	Iterator Itr = set.iterator();
	while (Itr.hasNext()) {
		Map.Entry e=(Entry) Itr.next();
		System.out.println(e.getKey()+ " " +e.getValue());

	}

}

}
