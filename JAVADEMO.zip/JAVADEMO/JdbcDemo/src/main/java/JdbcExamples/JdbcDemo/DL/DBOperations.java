package JdbcExamples.JdbcDemo.DL;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import JdbcExamples.JdbcDemo.BL.Emp;
import JdbcExamples.JdbcDemo.BL.Emp2;
import JdbcExamples.JdbcDemo.BL.Employee;
import JdbcExamples.JdbcDemo.BL.Report1;
import JdbcExamples.JdbcDemo.BL.Report2;
import oracle.jdbc.OracleTypes;

public class DBOperations {

	public static String insertEmp2(Emp2 E) {
		Connection Con = null;
		PreparedStatement PStmt = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + " Driver Error");
		}

		// Step 2 2. Create Connection Object

		try {
			Con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error" + e.getMessage());
		}
		DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MMM-yy");
		try {
			System.out.println(D.format(E.getHiredate()));
			PStmt = Con.prepareStatement("insert into Emp values(?,?,?,?,?,?,?,?)");

			PStmt.setInt(1, E.getEmpno());
			PStmt.setString(2, E.getEname());
			PStmt.setString(3, E.getJob());
			PStmt.setInt(4, E.getMgr());
			PStmt.setString(5, D.format(E.getHiredate()));
			PStmt.setInt(6, E.getSal());
			PStmt.setInt(7, E.getComm());
			PStmt.setInt(8, E.getDeptno());
			int row = PStmt.executeUpdate();
			return row + " row inserted";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}

		finally {
			try {
				Con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static String insertEmp(Emp E) {

		Connection Con = null;
		PreparedStatement PStmt = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + " Driver Error");
		}

		// Step 2 2. Create Connection Object

		try {
			Con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error" + e.getMessage());
		}

		try {
			PStmt = Con.prepareStatement("insert into Emp values(?,?,?,?,?,?,?,?)");
			PStmt.setInt(1, E.getEmpno());
			PStmt.setString(2, E.getEname());
			PStmt.setString(3, E.getJob());
			PStmt.setInt(4, E.getMgr());
			PStmt.setString(5, E.getHiredate());
			PStmt.setInt(6, E.getSal());
			PStmt.setInt(7, E.getComm());
			PStmt.setInt(8, E.getDeptno());
			int row = PStmt.executeUpdate();
			return row + " row inserted";

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			if (e.getMessage().contains("SYSTEM.SYS_C007853"))
				return "Empno must be unique";

			return e.getMessage();
		} finally {
			try {
				Con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	public static String insertEmployee(Employee E) {

		Connection Con = null;
		PreparedStatement PStmt = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + " Driver Error");
		}

		// Step 2 2. Create Connection Object

		try {
			Con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error" + e.getMessage());
		}

		try {
			PStmt = Con.prepareStatement("insert into Employee values(?,?,?,?,?,?)");
			PStmt.setInt(1, E.getEmpno());
			PStmt.setString(2, E.getEname());
			PStmt.setString(3, E.getGender());
			PStmt.setString(4, E.getDob());
			PStmt.setString(5, E.getEmail());
			PStmt.setInt(6, E.getDeptno());
			int row = PStmt.executeUpdate();
			return row + " row inserted";

		} catch (SQLException e) {
			if (e.getMessage().contains("PK_EMPNO"))
				return "Employee No cannot be duplicate";
			else if (e.getMessage().contains("CK_GENDER"))
				return "Gender must be Male or Female or Others";
			else if (e.getMessage().contains("CK_DOB"))
				return "Dob > 01-Jan-1970";
			else if (e.getMessage().contains("UQ_EMAIL"))
				return "Email mist be unique";
			else if (e.getMessage().contains("ref_deptno"))
				return "Invalid Deptno";
			else if (e.getMessage().contains("NULL") && e.getMessage().contains("ENAME"))
				return "Ename cannot be null";
			else if (e.getMessage().contains("NULL") && e.getMessage().contains("EMAIL"))
				return "Email cannot be null";

			else
				return "Invalid data";

		} finally {
			try {
				Con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	public static ArrayList<Emp> getDetails(int dno) {

		Connection Con = null;
		PreparedStatement PStmt = null;
		ArrayList<Emp> elist = new ArrayList<Emp>();
		Emp E = null;
		// Step 1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + " Driver Error");
		}

		// Step 2 2. Create Connection Object

		try {
			Con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error" + e.getMessage());
		}

		// Step 3 & 4
		// Step3
		try {
			PStmt = Con.prepareStatement("select * from emp where deptno=?");
			PStmt.setInt(1, dno);
			// step4
			ResultSet R = PStmt.executeQuery();
			if (!R.next()) {
				System.out.println("No records with this dept exists");
			} else {
				do {
					// DateTimeFormatter D=DateTimeFormatter.ofPattern("yyyy-MM-dd");
					E = new Emp(R.getInt(1), R.getString(2), R.getString(3), R.getInt(4), R.getString(5), R.getInt(6),
							R.getInt(7), R.getInt(8));
					elist.add(E);

				} while (R.next());
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + "Statement");
		}
		return elist;
	}

	public static ArrayList<Report1> extractJoins()
	{
		Connection Con = null;
		CallableStatement Cstmt = null;
		Scanner S = new Scanner(System.in);
		Report1 report = null;
		ArrayList<Report1> list = new ArrayList<Report1>();
		// Step 1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + " Driver Error");
		}

		// Step 2 2. Create Connection Object

		try {
			Con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error" + e.getMessage());
		}
		try {
			Cstmt = Con.prepareCall("{call sp_extractwithJoins(?)}");
			Cstmt.registerOutParameter(1, OracleTypes.CURSOR);
			Cstmt.execute();
			ResultSet R = (ResultSet) Cstmt.getObject(1);
			if (!R.next()) {
				System.out.println("No data exists");
			} else {
				do {
					report = new Report1(R.getInt(1), R.getString(2), R.getString(3), R.getString(4));
					list.add(report);
				} while (R.next());
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				Con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return list;
	}
	
	public static Map<String,Integer> getSummary()
	{
		
		Connection Con = null;
		CallableStatement Cstmt = null;
		Map<String,Integer>map=new TreeMap<String, Integer>();
		// Step 1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + " Driver Error");
		}

		// Step 2 2. Create Connection Object

		try {
			Con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error" + e.getMessage());
		}
		
		try {
			Cstmt=Con.prepareCall("{call sp_extractwithgroup(?)}");
			Cstmt.registerOutParameter(1, OracleTypes.CURSOR);
			Cstmt.execute();
			ResultSet R=(ResultSet) Cstmt.getObject(1);
			while(R.next())
			{
			map.put(R.getString(1),R.getInt(2));	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
		try {
			Con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return map;
		
		
	}

	
	
	
	
	public static ArrayList<Report2> getSummary2()
	{
		
		Connection Con = null;
		CallableStatement Cstmt = null;
		Report2 report2=null;
		ArrayList<Report2> list=new ArrayList<Report2>();
		
		
		// Step 1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() + " Driver Error");
		}

		// Step 2 2. Create Connection Object

		try {
			Con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Error" + e.getMessage());
		}
		
		try {
			Cstmt=Con.prepareCall("{call sp_extractwithgroup(?)}");
			Cstmt.registerOutParameter(1, OracleTypes.CURSOR);
			Cstmt.execute();
			ResultSet R=(ResultSet) Cstmt.getObject(1);
			while(R.next())
			{
			report2=new Report2(R.getString(1),R.getInt(2));
			list.add(report2);	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
		try {
			Con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return list;
		
		
	}

	
	
	
	
	
	
	
	
}