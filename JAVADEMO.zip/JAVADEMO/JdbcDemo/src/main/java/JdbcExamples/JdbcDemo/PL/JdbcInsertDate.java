package JdbcExamples.JdbcDemo.PL;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import JdbcExamples.JdbcDemo.BL.Emp2;
import JdbcExamples.JdbcDemo.BL.EmpBl;

public class JdbcInsertDate {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	System.out.println("enter details");
	int empno=S.nextInt();
	S.nextLine();
	String ename=S.nextLine();
	String job=S.nextLine();
	int mgr=S.nextInt();
	S.nextLine();
	String dt=S.nextLine();
	DateTimeFormatter D=DateTimeFormatter.ofPattern("MM/dd/yyyy");
	LocalDate hiredate=LocalDate.parse(dt,D);
	System.out.println(hiredate + " In main");
	int sal=S.nextInt();
	int comm=S.nextInt();
	int deptno=S.nextInt();
	Emp2 E=new Emp2(empno,ename,job,mgr,hiredate,sal,comm,deptno);
	EmpBl EB=new EmpBl();
	String Str=EB.insertEmpDate(E);
	System.out.println(Str);
}
}
