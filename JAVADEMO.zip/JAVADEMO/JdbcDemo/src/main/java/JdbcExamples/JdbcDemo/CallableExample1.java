package JdbcExamples.JdbcDemo;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class CallableExample1 {
public static void main(String[] args) {
	
	Scanner S=new Scanner(System.in);
	System.out.println("Enter the details");
	int eno=S.nextInt();
	S.nextLine();
	String en=S.nextLine();
	String g=S.nextLine();
	String d=S.nextLine();
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	LocalDate db=LocalDate.parse(d,D);
	String email=S.nextLine();
	int dno=S.nextInt();
	
	Connection Con=null;
	CallableStatement Cstmt=null;
	//Step 1
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage()+ " Driver Error");
			}
			
			//Step 2  2.	Create Connection Object
			
			try {
				Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Connection Error"+ e.getMessage());
			}
		
			try {
				Cstmt=Con.prepareCall("{call sp_insert2(?,?,?,?,?,?,?)}");
				Cstmt.setInt(1, eno);
				Cstmt.setString(2, en);
				Cstmt.setString(3, g);
				Cstmt.setString(4, D.format(db));
				Cstmt.setString(5, email);
				Cstmt.setInt(6, dno);
				Cstmt.registerOutParameter(7, Types.VARCHAR,150);
				Cstmt.execute();
				System.out.println(Cstmt.getString(7));
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			finally {
				try {
					Con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
		
				
}
}
