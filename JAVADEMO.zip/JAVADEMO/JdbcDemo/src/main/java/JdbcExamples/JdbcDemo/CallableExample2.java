package JdbcExamples.JdbcDemo;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class CallableExample2 {
public static void main(String[] args) {
	
	Scanner S=new Scanner(System.in);
	System.out.println("Enter the details");
	int eno=S.nextInt();
	S.nextLine();
	String en=S.nextLine();
	String g=S.nextLine();
	String d=S.nextLine();
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	LocalDate db=LocalDate.parse(d,D);
	String email=S.nextLine();
	int dno=S.nextInt();
	
	Connection Con=null;
	CallableStatement Cstmt=null;
	//Step 1
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage()+ " Driver Error");
			}
			
			//Step 2  2.	Create Connection Object
			
			try {
				Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Connection Error"+ e.getMessage());
			}
		try {
			Cstmt=Con.prepareCall("{call sp_insert(?,?,?,?,?,?)}");
			Cstmt.setInt(1, eno);
			Cstmt.setString(2, en);
			Cstmt.setString(3, g);
			Cstmt.setString(4, D.format(db));
			Cstmt.setString(5, email);
			Cstmt.setInt(6, dno);
			int R=Cstmt.executeUpdate();
			System.out.println(R + " rows inserted");
			
			
		} catch (SQLException e) {
			if(e.getMessage().contains("PK_EMPNO"))
				System.out.println("Employee No cannot be duplicate");
			else if(e.getMessage().contains("CK_GENDER"))
				System.out.println("Gender must be Male or Female or Others");
			else if(e.getMessage().contains("CK_DOB"))
				System.out.println("Dob > 01-Jan-1970");
			else if(e.getMessage().contains("UQ_EMAIL"))
				System.out.println("Email mist be unique");
			else if(e.getMessage().contains("ref_deptno"))
				System.out.println("Invalid Deptno");
			else if(e.getMessage().contains("NULL") && e.getMessage().contains("ENAME"))
				System.out.println("Ename cannot be null");
			else if(e.getMessage().contains("NULL") && e.getMessage().contains("EMAIL"))
				System.out.println("Email cannot be null");
			
			else
				System.out.println("Invalid data");
		
			
			
		}
		
		finally {
			try {
				Con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
}
