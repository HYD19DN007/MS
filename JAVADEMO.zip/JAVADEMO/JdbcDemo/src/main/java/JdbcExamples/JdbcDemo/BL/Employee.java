package JdbcExamples.JdbcDemo.BL;

import java.time.LocalDate;
//POJO class
public class Employee {

	public Integer getEmpno() {
		return empno;
	}

	public String getEname() {
		return ename;
	}

	public String getGender() {
		return gender;
	}

	public String getDob() {
		return dob;
	}

	public String getEmail() {
		return email;
	}

	public Integer getDeptno() {
		return deptno;
	}

	public Employee(Integer empno, String ename, String gender, String dob, String email, Integer deptno) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.gender = gender;
		this.dob = dob;
		this.email = email;
		this.deptno = deptno;
	}

	private Integer empno;
	private String ename;
	private String gender;
	private String dob;
	private String email;
	private Integer deptno;

	public Employee() {
	}

	}
