package day9;

public class StringEx2 {
public static void main(String[] args) {
	String S = new String("Hello");
	String S1=S;
	//System.out.println(S1);
	//System.out.println(S);
	if(S==S1)
		System.out.println("Equal");
	else
		System.out.println("Not Equal");
	
	S=S+"All";
	if(S==S1)
		System.out.println("Equal");
	else
		System.out.println("Not Equal");
	
	//System.out.println(S1);
	//System.out.println(S);
	
	
	
	StringBuffer S2 = new StringBuffer("Hello");
	StringBuffer S3=S2;
	//System.out.println(S1);
	//System.out.println(S);
	if(S2==S3)
		System.out.println("Equal");
	else
		System.out.println("Not Equal");
	
	S2=S2.append("All");
	if(S2==S3)
		System.out.println("Equal");
	else
		System.out.println("Not Equal");



}
}
