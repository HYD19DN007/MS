package day9;


public class InterfaceEx2 {
public static void main(String[] args) {
	//IntfParent P=new Child();
	
}
}
