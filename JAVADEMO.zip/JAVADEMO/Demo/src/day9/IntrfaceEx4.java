package day9;
interface A
{
public void Method1();
}

interface B 
{
public void Method2();	
}
class C implements A,B
{
	public void Method1()
	{
		System.out.println("MEthod1 of C");
	}
	public void Method2()
	{
	System.out.println("Method2 of C");
	}
}

public class IntrfaceEx4 {
public static void main(String[] args) {
	A a=new C();
	a.Method1();
	B b=new C();
	b.Method2();
}
	
}
