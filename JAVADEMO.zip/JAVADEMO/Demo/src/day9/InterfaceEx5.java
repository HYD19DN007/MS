package day9;

interface IShape {
	double pi = 3.142;
	double Area();
	double Perimeter();
}

class Rectangle implements IShape {
	private double dim1;
	private double dim2;

	public Rectangle(double dim1, double dim2) {
		super();
		this.dim1 = dim1;
		this.dim2 = dim2;
	}

	@Override
	public double Area() {
		// TODO Auto-generated method stub
		return dim1 * dim2;
	}

	@Override
	public double Perimeter() {
		// TODO Auto-generated method stub
		return 2 * (dim1 + dim2);
	}

}

class Circle implements IShape {
	private double radius;

	public Circle(double radius) {
		super();
		this.radius = radius;
	}

	@Override
	public double Area() {
		// TODO Auto-generated method stub
		return pi * radius * radius;
	}

	@Override
	public double Perimeter() {
		// TODO Auto-generated method stub
		return 2 * pi * radius;
	}
}

public class InterfaceEx5 {
	public static void main(String[] args) {
		IShape S = null;
		//S=new Rectangle(10,20);
		S = new Circle(10.5);

		System.out.println(S.Area());
		System.out.println(S.Perimeter());

	}
}
