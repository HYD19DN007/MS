package day9;

public class Child1 implements IntfParent
{

}
