package day9;

public interface IntfParent {
		int a=10;
		
		

}
