package day9;
interface IParent
{
	void Method1();
	void  Method2();
	void Method3();
}
//Partial implementation
 class Child implements IParent
{
	public void Method1()
	{
		System.out.println("Method1");
	}
	public void Method2()
	{
		System.out.println("Method2");
	}
	public void Method3()
	{
		System.out.println("Method3");
		Method4();
	}
	public void Method4()
	{
		System.out.println("Method4");
	}

	public void Method5()
	{
		System.out.println("Method5");
	}

}


public class InterfaceEx1 {
public static void main(String[] args) {
	
	}
}
