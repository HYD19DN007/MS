package day9;
interface intf{
	void method1();
}
interface Intf1{
	void method2();
}
class ParentCls{}
class ParentCls1{}

class Childcls extends ParentCls implements intf,Intf1
{

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		
	}
	


}
public class InterfaceEx9 {

}
