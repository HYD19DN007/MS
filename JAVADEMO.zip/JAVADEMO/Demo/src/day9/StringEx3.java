package day9;

public class StringEx3 {
public static void main(String[] args) {
	String S = new String("Helloall");
	String S1 = new String("Hello");
	String S2 = new String("hello");
	
	System.out.println(S.charAt(2));
	if(S.equals(S1))
		System.out.println("Equal");
	else
		System.out.println("Not Equal");
		
	System.out.println(S.compareTo(S1));
	System.out.println(S2.compareTo(S));
	System.out.println((int)'H');
	System.out.println((int)'h');
	System.out.println(S1.compareToIgnoreCase(S2));
	System.out.println(S+ S1);
	System.out.println(S.concat(S1));
	System.out.println(S.hashCode());
	System.out.println(S.substring(2));
	System.out.println(S.substring(2, 5));
	StringBuffer S3=new StringBuffer("Hello");
	

}
}
