package day9;

public class StringEx1 {
	public static void main(String[] args) {
		String S = new String("Hello");
		String S1 = new String("Hello");
		if(S==S1)
			System.out.println("Equal");
		else
			System.out.println("Not equal");

		if(S.equals(S1))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		System.out.println();
		
		String S2=S1;
		
		if(S2==S1)
			System.out.println("Equal");
		else
			System.out.println("Not equal");

		if(S2.equals(S1))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");

		
		
		
		
		
	}

}
