

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;



public class Mainfunc {
public static void main(String[] args) {
	System.out.println("Enter Contact 1 detail:"+"\n"+"Contact1:");
	Scanner S = new Scanner(System.in);
	String str = S.nextLine();
	String []S1 = str.split(",");
	DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	Contact C1= new Contact(S1[0], S1[1], S1[2], S1[3], S1[4], S1[5],LocalDate.parse(S1[6], D));		
	System.out.println(C1.toString());
	System.out.println();
	System.out.println("Enter Contact 2 details:"+"\n"+"Contact2:");
	String str1= S.nextLine();
	String[] S2 = str1.split(",");
	Contact C2 = new Contact(S2[0], S2[1], S2[2], S2[3], S2[4], S2[5],LocalDate.parse(S2[6], D));	
	System.out.println(C2.toString());
	System.out.println();
	 if (C1.equals(C2)) {
         System.out.println("Contact 1 is same as Contact 2");
     } else {
         System.out.println("Contact 1 and Contact 2 are different");
     }
}
}
