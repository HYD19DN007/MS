package day10;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CollectionEx1 {
public static void main(String[] args) {
	List<Integer>L=new ArrayList<Integer>();
	L.add(10);
	L.add(20);
	L.add(30);
	L.add(50);
	List<Double>L1=new ArrayList<Double>();
	L1.add(10.5);
	L1.add(20.6);
	L1.add(30.8);
	List<String>L2=new ArrayList<String>();
	L2.add("one");
	L2.add("two");
	L2.add("three");
	
	for(int i=0;i<L2.size();i++)
	{
		System.out.println(L2.get(i));
	}
	
	for (String s : L2) {
		System.out.println(s);
	}
	System.out.println();
	System.out.println();
	Iterator<Integer> itr=L.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
	
}
}
