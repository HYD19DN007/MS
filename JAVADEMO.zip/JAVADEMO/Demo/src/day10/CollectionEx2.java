package day10;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

public class CollectionEx2 {
public static void main(String[] args) {
	Stack<Integer> S=new Stack<Integer>();
	S.push(10);
	S.push(20);
	S.push(30);
	for(Integer i :S)
	{
		System.out.println(i);
	}
	System.out.println();
	System.out.println(S.pop());
	System.out.println();
	for(Integer i :S)
	{
		System.out.println(i);
	}
	System.out.println();
	System.out.println(S.pop());
	System.out.println();
	for(Integer i :S)
	{
		System.out.println(i);
	}
	System.out.println();
	Queue<Integer> Q=new LinkedList<Integer>();
	Queue<Integer>Q1=new PriorityQueue<Integer>();
	Q.add(10);
	Q.add(20);
	Q.add(30);
	for(Integer i:Q)
	{
		System.out.println(i);
	}
	Iterator<Integer> itr=Q.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
}
}
