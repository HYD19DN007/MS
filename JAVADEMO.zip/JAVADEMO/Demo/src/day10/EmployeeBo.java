package day10;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

interface IEmployeeBo
{
	Employee FetchByEmpno(int eno,List<Employee>elist);
	List<Employee> FetchByDob(LocalDate db,List<Employee>elist);
	List<Employee>FetchByBasic(double basic,List<Employee>elist);
	void SortByDob(List<Employee>elist);
}


public class EmployeeBo implements IEmployeeBo
{

	@Override
	public Employee FetchByEmpno(int eno, List<Employee> elist) {
		
		for(Employee e:elist)
		{
			if(e.getEmpno()==eno)
			{
				return e;
			}
		}
		return null;
	}

	@Override
	public List<Employee> FetchByDob(LocalDate db, List<Employee> elist) {
		List<Employee>newlist=new ArrayList<Employee>();
		for(Employee e:elist)
		{
			if(e.getDob().compareTo(db)>0)
			{
				newlist.add(e);
			}
		}
		return newlist;
	}

	@Override
	public List<Employee> FetchByBasic(double basic, List<Employee> elist) {
		List<Employee>newlist=new ArrayList<Employee>();
		for(Employee e:elist)
		{
			if(e.getBasic()>basic)
			{
				newlist.add(e);
			}
		}
		return newlist;
	}

	@Override
	public void SortByDob(List<Employee> elist) {
		Employee temp;
		for(int i=0;i<elist.size()-1;i++)
		{
			for(int j=i+1;j<elist.size();j++)
			{
				if(elist.get(i).getDob().compareTo(elist.get(j).getDob())>0)
				{
					temp=elist.get(i);
					elist.set(i, elist.get(j));
					elist.set(j, temp);
					
				}
				
			}
		}
	}

		
}
