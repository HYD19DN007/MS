package day10;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CollectionEx3 {

	public static void main(String[] args) {
		List<Employee>list=new ArrayList<Employee>();
		
		Employee E=new Employee(1, "RAM", LocalDate.parse("2000-09-01"), 200000);
		list.add(E);
		E=new Employee(2, "RAHUL", LocalDate.parse("2001-09-01"), 300000);
		list.add(E);
		for(Employee emp:list)
		{
			System.out.println(emp.Print());
		}
		
		
	}
	
}
