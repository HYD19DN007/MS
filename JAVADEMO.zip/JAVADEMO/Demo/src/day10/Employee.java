package day10;

import java.time.LocalDate;

public class Employee {
	
	private int empno;
	private String ename;
	private LocalDate dob;
	private double basic;

	public Employee() {
	}

	public Employee(int eno, String en, LocalDate db, double bas) {
		super();
		this.empno = eno;
		this.ename = en;
		this.dob = db;
		this.basic = bas;
	}

	public String Print() {
		return empno + " " + ename + " " + dob + " " + basic;
	
	}
	public int getEmpno() {
		return empno;
	}

	public LocalDate getDob() {
		return dob;
	}

	public double getBasic() {
		return basic;
	}

	
}
