import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class Demo {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	String St=S.nextLine();
	LocalDate D1=LocalDate.parse(St);
	System.out.println(D1);
	int a[]= {1,2,3,4,5};
	a[6]=100;
	
	SimpleDateFormat Sf=new SimpleDateFormat("yyyy-MM-dd");
	//Date D=Sf.parse(St);
	
	
	
	//System.out.println(D);
	System.out.println(a[6]);
	
}
}
