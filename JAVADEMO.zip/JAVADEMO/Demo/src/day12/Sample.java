package day12;
interface IDemo
{
	void Method1();
	void Method2();
}

public class Sample {
public static void main(String[] args) {

IDemo D=new IDemo() {
	
	@Override
	public void Method2() {
		System.out.println("Method2");
		
	}
	
	@Override
	public void Method1() {
		// TODO Auto-generated method stub
		System.out.println("Method1");
	}
};	
	
IDemo D1=new IDemo() {
	
	@Override
	public void Method2() {
		System.out.println("Method2 of D1 object");
	}
	
	@Override
	public void Method1() {
		// TODO Auto-generated method stub
		System.out.println("Method1 of D2 object");
	}
};
D.Method1();
D.Method2();
D1.Method1();D1.Method2();
}

}
