package day12;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import day11.Employee;

public class TreeMapEx1 {
	public static void main(String[] args) {
		ArrayList<Emp> elist = new ArrayList<Emp>();
		Emp E = new Emp(1, "Ram", LocalDate.parse("2000-09-01"), 40000, 10);
		elist.add(E);
		E = new Emp(9, "Ramu", LocalDate.parse("2000-10-01"), 23000, 20);
		elist.add(E);
		E = new Emp(2, "Rahul", LocalDate.parse("2000-09-01"), 50000, 10);
		elist.add(E);
		E = new Emp(3, "James", LocalDate.parse("2001-08-01"), 60000, 30);
		elist.add(E);
		E = new Emp(4, "Ravi", LocalDate.parse("2002-10-24"), 70000, 10);
		elist.add(E);
		E = new Emp(5, "Scott", LocalDate.parse("1999-07-13"), 45000, 30);
		elist.add(E);
		E = new Emp(6, "Adams", LocalDate.parse("1998-03-01"), 20000, 10);
		elist.add(E);
		E = new Emp(7, "Rani", LocalDate.parse("2000-12-01"), 70000, 20);
		elist.add(E);
		E = new Emp(8, "Jones", LocalDate.parse("2001-11-01"), 25000, 10);
		elist.add(E);
		Map<Integer, Integer> M = new TreeMap<Integer, Integer>();
		int n;
		for (Emp e : elist) {
			if (M.containsKey(e.getDeptno())) {
				n = M.get(e.getDeptno());
				M.put(e.getDeptno(), n + 1);

			} else {
				M.put(e.getDeptno(), 1);

			}
		}
		System.out.println("Output");

		Set set = M.entrySet();
		Iterator Itr = set.iterator();
		while (Itr.hasNext()) {
			System.out.println(Itr.next());
		}

		System.out.println();
		
		Map<Integer, Double> MSal = new TreeMap<Integer, Double>();
				
		for (Emp e : elist) {
			if(MSal.containsKey(e.getDeptno()))
			{
				Double s=MSal.get(e.getDeptno());
				MSal.put(e.getDeptno(), s+e.getBasic());
				
			}
			else
			{
				MSal.put(e.getDeptno(),e.getBasic());
			}
			
			
		
		
		}
			
			System.out.println("Output");

		Set set1 = MSal.entrySet();
		Iterator Itr1 = set1.iterator();
		while (Itr1.hasNext()) {
			System.out.println(Itr1.next());
		}

		
		
		
		
		
	}
}
