package day12;

import java.time.LocalDate;

public class Emp{
	private int empno;
	private String ename;
	private LocalDate dob;
	private double basic;
	private int deptno;

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public Emp() {
		super();
	}

	public Emp(int empno, String ename, LocalDate dob, double basic,int deptno) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.dob = dob;
		this.basic = basic;
		this.deptno=deptno;
	}

	public int getEmpno() {
		return empno;
	}

	public String getEname() {
		return ename;
	}

	public LocalDate getDob() {
		return dob;
	}

	public double getBasic() {
		return basic;
	}

	
	public String toString() {
		return empno + " " + ename + " " + basic + " " + dob;
	}
	public String Print() {
		return empno + " " + ename + " " + basic + " " + dob;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public void setBasic(double basic) {
		this.basic = basic;
	}

	
}
