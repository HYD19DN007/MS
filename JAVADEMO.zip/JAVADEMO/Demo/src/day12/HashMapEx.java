package day12;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class HashMapEx {
public static void main(String[] args) {
	Map<String, Integer> M=new HashMap<String, Integer>();
	M.put("Rachana", 45425543);
	M.put("Monoj", 3422221);
	M.put("Mohan", 545322);
	M.put("Aman", 454255);
	M.put("Aman", 454256);
	System.out.println(M.get("Rachana"));
	Set set=M.entrySet();
	Iterator Itr=set.iterator();
	while(Itr.hasNext())
	{
	Map.Entry e=(Entry) Itr.next();
	System.out.println(e.getKey()+ " " +e.getValue());
	}
	System.out.println();


	Map<String, Integer> TM=new TreeMap<String, Integer>();
	TM.put("Rachana", 45425543);
	TM.put("Monoj", 3422221);
	TM.put("Mohan", 545322);
	TM.put("Aman", 454255);
	TM.put("Aman", 454256);
	System.out.println(TM.get("Rachana"));
	Set set1=TM.entrySet();
	Iterator Itr1=set1.iterator();
	while(Itr1.hasNext())
	{
	Map.Entry e=(Entry) Itr1.next();
	System.out.println(e.getKey()+ " " +e.getValue());
	}
}
}
