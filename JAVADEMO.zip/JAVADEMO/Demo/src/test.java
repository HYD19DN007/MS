import java.util.ArrayList;
import java.util.List;

import day5.Employee;

public class test {
public static void main(String[] args) {
	List<Employee> list=new ArrayList<Employee>();
	list.add(new Employee(1,"a",30000));
	list.add(new Employee(2,"b",30000));
	list.add(new Employee(1,"b",30000));
	list.forEach(i->System.out.println(i.empno+ " "+ i.ename+ " "+i.basic));
}
}
