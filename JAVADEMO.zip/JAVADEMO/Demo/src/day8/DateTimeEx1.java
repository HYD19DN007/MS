package day8;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Period;

public class DateTimeEx1 {
public static void main(String[] args) {
	LocalDateTime L=LocalDateTime.now();
	System.out.println(L);
	LocalDateTime L1=LocalDateTime.of(2025, 9, 23, 12, 30, 20);
	System.out.println(L1);
	LocalDateTime L2=LocalDateTime.of(2025, 9, 23, 12, 30, 10);
	System.out.println(L2);
	Duration d=Duration.between(L1, L2);
	System.out.println(d.toHoursPart()+ " "+d.toMinutesPart() + " "+ d.toSecondsPart());
	System.out.println(L1.compareTo(L2));
}
}
