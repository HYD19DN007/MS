package day8;

import day9.Child1;
import day9.IntfParent;

public class sss{

	public sss()
	{
		IntfParent P=new Child1();
		System.out.println(IntfParent.a);
	}
	
}
