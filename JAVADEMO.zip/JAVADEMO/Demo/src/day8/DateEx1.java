package day8;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

public class DateEx1 {
public static void main(String[] args) {
	Scanner Sc=new Scanner(System.in);
	LocalDate L=LocalDate.now();
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MM-yyyy");
	System.out.println(L.format(D));
	DateTimeFormatter D1=DateTimeFormatter.ofPattern("MM-dd-yyyy");
	System.out.println(L.format(D1));
	DateTimeFormatter D2=DateTimeFormatter.ofPattern("MMM-dd-yyyy");
	System.out.println(L.format(D2));
	DateTimeFormatter D3=DateTimeFormatter.ofPattern("MMMM-dd-yyyy");
	System.out.println(L.format(D3));
	DateTimeFormatter D4=DateTimeFormatter.ofPattern("MMMM/dd/yy");
	System.out.println(L.format(D4));
	//Accept the date
	LocalDate dob=LocalDate.of(1980, 9, 5);
	System.out.println(dob);
	System.out.println("Enter Date");
	String S=Sc.nextLine();
	DateTimeFormatter D5=DateTimeFormatter.ofPattern("MMM-dd-yyyy");
	LocalDate dob1=LocalDate.parse(S,D5);
	
	System.out.println(dob1);
	LocalDate add=dob1.plusYears(5);
	System.out.println(add);
	LocalDate adddays=add.plusDays(45);
	System.out.println(adddays);
	System.out.println(Period.between(dob1, LocalDate.now()).getMonths());
	System.out.println(dob1.getMonth() );
	System.out.println(dob1.getMonthValue());
	
	
}
}
