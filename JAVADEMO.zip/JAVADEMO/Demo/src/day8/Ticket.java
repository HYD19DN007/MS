package day8;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Ticket {
	private String _ticketNo;
	private LocalDateTime _parkedTime;
	private double _cost;
	public Ticket() {}
	
	public Ticket(String _ticketNo, LocalDateTime _parkedTime, double _cost) {
	
		super();
		this._ticketNo = _ticketNo;
		this._parkedTime = _parkedTime;
		this._cost = _cost;
	}
	public String toString()
	{
		DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		
		return _ticketNo + " "+_parkedTime.format(D)+ " "+ _cost;
	}
	public LocalDateTime getParkedTime()
	{
		return _parkedTime;
	}
	
}
