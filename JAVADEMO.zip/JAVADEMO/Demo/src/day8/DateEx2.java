package day8;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateEx2 {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	System.out.println("Enter the dates");
	String S1=S.nextLine();
	String S2=S.nextLine();
	DateTimeFormatter D=DateTimeFormatter.ofPattern("MM/dd/yyyy");
	LocalDate L=LocalDate.parse(S1,D);
	LocalDate L1=LocalDate.parse(S2,D);
	System.out.println(L.compareTo(L1));   //5-8     8-5   8-8
	int a=10,b=20;
	
	
}
}
