package day8;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Vehicle {

	private String _registrationNo;

	private String _name;
	private String _type;
	private double _weight;
	private Ticket _ticket;

	public Vehicle() {
	}

	public Vehicle(String _registrationNo, String _name, String _type, double _weight, Ticket _ticket) {
		super();
		this._registrationNo = _registrationNo;
		this._name = _name;
		this._type = _type;
		this._weight = _weight;
		this._ticket = _ticket;
	}

	static Vehicle CreateVehicle(String detail) {
		String Str[] = detail.split(",");
		DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		Ticket T = new Ticket(Str[4], LocalDateTime.parse(Str[5], D), Double.parseDouble(Str[6]));
		Vehicle V = new Vehicle(Str[0], Str[1], Str[2], Double.parseDouble(Str[3]), T);
		return V;
	}
	
	static void SortByWeight(Vehicle V[])
	{
		Vehicle temp;
		for(int i=0;i<V.length-1;i++)
		{
			for(int j=i+1;j<V.length;j++)
			{
				if(V[i]._weight>V[j]._weight)
				{
					temp=V[i];
					V[i]=V[j];
					V[j]=temp;
				}
			}
		}
	}
	static void SortByParkedTime(Vehicle V[])
	{
		Vehicle temp;
		for(int i=0;i<V.length-1;i++)
		{
			for(int j=i+1;j<V.length;j++)
			{
				if(V[i]._ticket.getParkedTime().compareTo(V[j]._ticket.getParkedTime())>0)
				{
					temp=V[i];
					V[i]=V[j];
					V[j]=temp;
				}
			}
		}
	}
	
	
	
	public String toString()
	{
		return _registrationNo+ " "+ _name+ " "+_type+ " "+_weight+ " " +_ticket;
		
	}
	
	
}
