package day8;

import java.util.Scanner;

public class AssignemtnEx {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	System.out.println("Enter the number of the vehicles");
	int n=S.nextInt();
	S.nextLine();
	String Str;
	Vehicle V[]=new Vehicle[n];
	
	for (int i = 0; i < V.length; i++) {
		Str=S.nextLine();
		V[i]=Vehicle.CreateVehicle(Str);
	
	}
	Vehicle.SortByWeight(V);
	
for(int i=0;i<V.length;i++)
	{
		System.out.println(V[i]);
	}
	System.out.println();
	Vehicle.SortByParkedTime(V);
	for(int i=0;i<V.length;i++)
	{
		System.out.println(V[i]);
	}
	
}
}
