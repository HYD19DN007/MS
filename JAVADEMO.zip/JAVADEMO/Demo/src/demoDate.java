import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class demoDate {
public static void main(String[] args) {
	String dt="1980-01-02";
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDate L=LocalDate.parse(dt);
	System.out.println(L);
	DateTimeFormatter D1=DateTimeFormatter.ofPattern("yyyy-MMM-dd");
	System.out.println(L.format(D1));
	
	//1980-Feb-01
}
}
