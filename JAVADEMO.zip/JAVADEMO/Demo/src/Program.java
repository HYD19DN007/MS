
import java.util.Scanner;

public class Program {


public static boolean ValidateRegNo(String regNo) {
		String[] parts = regNo.split(" ");
        if (parts.length < 2 || parts.length > 4) {
            return false;
        }
        else if (parts[0].length() != 2 || !parts[0].matches("[A-Z]{2}")) {
            return false;
        }
        else if (parts[1].length() < 1 || parts[1].length() > 2 || !parts[1].matches("\\d{1,2}")) {
            return false;
        }
        else if (parts.length > 2 && !parts[2].matches("[A-Z]{0,2}")) {
            return false;
        }
        else if (parts.length == 4 && (!parts[3].matches("\\d{1,4}"))) {
            return false;
        }
        else if (parts.length == 3 && !parts[2].matches("\\d{1,4}")) {
            return false;
        }
        else
        return true;
    }



    public static void main(String[] args) {
        Scanner S = new Scanner(System.in);
        System.out.print("Enter the registration no. to be validated: ");
        String regNo = S.nextLine();
        if (ValidateRegNo(regNo)) {
            System.out.println("Registration No. is valid");
        } else {
            System.out.println("Registration No. is invalid");
        }
    }
}
