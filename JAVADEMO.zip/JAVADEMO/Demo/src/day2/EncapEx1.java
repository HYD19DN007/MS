package day2;
import java.util.Scanner;

class Sample {
	int a, b, c;
	void Accept(int a,int b,int c) {
		this.a=a;
		this.b=b;
		this.c=c;
	}
	String Print()
	{
		String S=a+ " "+ b + " "+c;
		return S;
	}
}

public class EncapEx1 {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		Sample S = new Sample();
		Sample S1 = new Sample();
		
		int i,j,k;
		System.out.println("Enter values");
		i=Sc.nextInt();
		j=Sc.nextInt();
		k=Sc.nextInt();
		//S.Accept(i,j,k);
		System.out.println("Enter values");
		i=Sc.nextInt();
		j=Sc.nextInt();
		k=Sc.nextInt();
		//S1.Accept(i, j, k);
		
		System.out.println(S.Print());
		String str=S1.Print();
		System.out.println(str);
		
	}
}
