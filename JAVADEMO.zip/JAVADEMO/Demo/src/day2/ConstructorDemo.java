package day2;

class Example {
	int a, b, c;
	//Default
	public Example() {
		a = 1;
		b = 2;
		c = 3;
	}
	//Parametrised
	public Example(int a,int b,int c) 
	{
		this.a=a;
		this.b=b;
		this.c=c;
	}
	//Parametrised
	public Example(int a) 
	{
		this.a=a;
		this.b=a;
		this.c=a;
	}
	//Parametrised
	public Example(int a,int b)
	{
		this.a=a;
		this.b=b;
		this.c=a-b;
				
	}
	//Copy
	public Example(Example A)
	{
		a=A.a*2;
		b=A.b*3;
		c=++A.c;
	}
	public Example(Example A,Example B)
	{
		a=A.a+B.a;
		b=A.b+B.b;
		c=A.c+B.c;
	}
}

public class ConstructorDemo {
	public static void main(String[] args) {
		Example E = new Example();
//		Example E1 = new Example(10,20,30);
//		Example E2 = new Example(100,200,300);
//		Example E3 = new Example(1000);
//		Example E4 = new Example(1000,2000);
//		Example E5=new Example(E1);
//		Example E6=new Example(E1,E2);
//		
//		System.out.println(E1);
//		System.out.println(E1.a + " " + E1.b + " " + E1.c);
//		System.out.println(E5.a + " " + E5.b + " " + E5.c);
//		System.out.println(E6.a + " " + E6.b + " " + E6.c);
//		System.out.println(E.a + " " + E.b + " " + E.c);
//		System.out.println(E1.a + " " + E1.b + " " + E1.c);
//		System.out.println(E2.a + " " + E2.b + " " + E2.c);
//		System.out.println(E3.a + " " + E3.b + " " + E3.c);
//		System.out.println(E4.a + " " + E4.b + " " + E4.c);

//		Example E=new Example(10,20,30);
//		Example E1=E;
//		System.out.println(E);
//		System.out.println(E1);
//		System.out.println(E.a + " " + E.b + " " + E.c);
//		System.out.println(E1.a + " " + E1.b + " " + E1.c);
//		E1.a++;
//		E1.b=E1.b+2;
//		E1.c=E1.c+3;
//		System.out.println(E.a + " " + E.b + " " + E.c);
		
		
		
		
		
		
	}
}
