package day2;
class Demo
{
	void Sum(int a,int b)
	{
		System.out.println("2 integers "+ (a+b));
	}
	
	void Sum(int a,int b,int c)
	{
		System.out.println("3 integers "+ (a+b+c));
	}
	void Sum(int a,int b,int c,int d)
	{
		System.out.println("4 intergers"+(a+b+c+d));
	}
	void Sum(float a,float b)
	{
		System.out.println("2 floats"+ (a+b));
	}
	void Sum(float a,float b,float c)
	{
		System.out.println("3 floats"+ (a+b+c));
	}
	
}


public class OverloadingEx1 {
public static void main(String[] args) {
	Demo D=new Demo();
	D.Sum(10,20);
	D.Sum(100,200,300);
	D.Sum(1000,2000,3000,4000);
	D.Sum(10.5f,20.6f);

}
}
