package day2;
class Test
{
public double Sum(double ... nos )
{
	double sum=0,sum1=0;
	for(int i=0;i<nos.length;i++)
	{
		sum1=sum1+nos[i];
	}
	for(double a:nos)
	{
		sum=sum+a;
	}
	return sum1;
}

}


public class Overloadex2 {
public static void main(String[] args) {
	Test T=new Test();
	System.out.println(T.Sum(10,20));
	System.out.println(T.Sum(10,20,30));
	System.out.println(T.Sum(10,20,30,40));
	System.out.println(T.Sum(10.6,20.7));
	System.out.println(T.Sum(10.1f,20.4f,9.3f));
}
}
