package day11;

import java.time.LocalDate;

public class Emp{
	private int empno;
	private String ename;
	private LocalDate dob;
	private double basic;

	public Emp() {
		super();
	}

	public Emp(int empno, String ename, LocalDate dob, double basic) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.dob = dob;
		this.basic = basic;
	}

	public int getEmpno() {
		return empno;
	}

	public String getEname() {
		return ename;
	}

	public LocalDate getDob() {
		return dob;
	}

	public double getBasic() {
		return basic;
	}

	
	public String Print() {
		return empno + " " + ename + " " + basic + " " + dob;
	}

	
}
