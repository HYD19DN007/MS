package day11;

import java.time.LocalDate;

public class Employee implements Comparable<Employee> {
	private int empno;
	private String ename;
	private LocalDate dob;
	private double basic;

	public Employee() {
		super();
	}

	public Employee(int empno, String ename, LocalDate dob, double basic) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.dob = dob;
		this.basic = basic;
	}

	public int getEmpno() {
		return empno;
	}

	public String getEname() {
		return ename;
	}

	public LocalDate getDob() {
		return dob;
	}

	public double getBasic() {
		return basic;
	}

	@Override
	public int compareTo(Employee o) {
		if (dob.compareTo(o.dob) > 0)
			return -1;
		else if (dob.compareTo(o.dob) < 0)
			return 1;
		else
			return 0;

	}

	public String Print() {
		return empno + " " + ename + " " + basic + " " + dob;
	}

}
