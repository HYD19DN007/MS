package day11;

import java.util.Comparator;

public class BasicComaparator implements Comparator<Emp>{

	@Override
	public int compare(Emp o1, Emp o2) {
		// TODO Auto-generated method stub
		return (int)(o1.getBasic()-o2.getBasic());
	}

}
