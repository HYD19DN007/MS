package day11;

import java.util.Comparator;

public class EnameComparator implements Comparator<Emp>
{

	@Override
	public int compare(Emp o1, Emp o2) {
		if(o1.getEname().compareTo(o2.getEname())>0)
			return 1;
		else if (o1.getEname().compareTo(o2.getEname())<0)
			return -1;
		else
			return 0;
	}

}
