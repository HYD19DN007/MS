package day11;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetEx {
public static void main(String[] args) {
	ArrayList<Integer> A=new ArrayList<Integer>();
	A.add(10);
	A.add(20);
	A.add(30);
	A.add(30);
	A.remove(0);
	A.add(40);
	for(Integer i:A)
	{
		System.out.println(i);
	}
	System.out.println();
	HashSet<Integer> H=new HashSet<Integer>();
	H.add(10);
	H.add(20);
	H.add(30);
	H.add(30);

	H.add(40);
	for(Integer i:H)
	{
		System.out.println(i);
	}
	System.out.println();
	TreeSet<Integer>T=new TreeSet<Integer>();
	T.add(10);
	T.add(20);
	T.add(20);
	T.add(30);
	T.add(40);
	for(Integer i:T)
	{
		System.out.println(i);
	}
	
	Iterator<Integer> itr=H.iterator();
	while(itr.hasNext())
	{
	System.out.println(itr.next());	
	}
	
}
}
