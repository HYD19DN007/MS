package day11;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MainComparator {
public static void main(String[] args) {
	ArrayList<Emp> elist = new ArrayList<Emp>();
	Emp E = new Emp(1, "Ram", LocalDate.parse("2000-09-01"), 40000);
	elist.add(E);
	E = new Emp(9, "Ramu", LocalDate.parse("2000-10-01"), 23000);
	elist.add(E);
	E = new Emp(2, "Rahul", LocalDate.parse("2000-09-01"), 50000);
	elist.add(E);
	E = new Emp(3, "James", LocalDate.parse("2001-08-01"), 60000);
	elist.add(E);
	E = new Emp(4, "Ravi", LocalDate.parse("2002-10-24"), 70000);
	elist.add(E);
	E = new Emp(5, "Scott", LocalDate.parse("1999-07-13"), 45000);
	elist.add(E);
	E = new Emp(6, "Adams", LocalDate.parse("1998-03-01"), 20000);
	elist.add(E);
	E = new Emp(7, "Rani", LocalDate.parse("2000-12-01"), 70000);
	elist.add(E);
	E = new Emp(8, "Jones", LocalDate.parse("2001-11-01"), 25000);
	elist.add(E);
	Scanner S=new Scanner(System.in);
	System.out.println("Enter the choice 1-3  byName,ByDob ByBasic");
	int n=S.nextInt();
	if(n==1)
	{
		Collections.sort(elist,new EnameComparator());
	}
	else if(n==2)
	{
		Collections.sort(elist,new DobComparator());
	}
	else if(n==3)
	{
		Collections.sort(elist,new BasicComaparator());
	}
	else
		System.out.println("Invalid choice");
	
	for(Emp e : elist)
	{
		System.out.println(e.Print());
	}
	
}
}
