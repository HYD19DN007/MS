package day11;

import java.util.Comparator;

public class DobComparator implements Comparator<Emp> {

	@Override
	public int compare(Emp o1, Emp o2) {
		// TODO Auto-generated method stub
		return o1.getDob().compareTo(o2.getDob());
	}

}
