package day11;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class MainComarable {
public static void main(String[] args) {
	ArrayList<Employee> elist = new ArrayList<Employee>();
	Employee E = new Employee(1, "Ram", LocalDate.parse("2000-09-01"), 40000);
	elist.add(E);
	E = new Employee(9, "Ramu", LocalDate.parse("2000-10-01"), 23000);
	elist.add(E);
	E = new Employee(2, "Rahul", LocalDate.parse("2000-09-01"), 50000);
	elist.add(E);
	E = new Employee(3, "James", LocalDate.parse("2001-08-01"), 60000);
	elist.add(E);
	E = new Employee(4, "Ravi", LocalDate.parse("2002-10-24"), 70000);
	elist.add(E);
	E = new Employee(5, "Scott", LocalDate.parse("1999-07-13"), 45000);
	elist.add(E);
	E = new Employee(6, "Adams", LocalDate.parse("1998-03-01"), 20000);
	elist.add(E);
	E = new Employee(7, "Rani", LocalDate.parse("2000-12-01"), 70000);
	elist.add(E);
	E = new Employee(8, "Jones", LocalDate.parse("2001-11-01"), 25000);
	elist.add(E);
	Collections.sort(elist);
	for(Employee e:elist)
	{
		System.out.println(e.Print());
	}
	
}

}
