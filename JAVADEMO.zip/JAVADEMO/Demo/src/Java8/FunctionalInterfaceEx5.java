package Java8;
@FunctionalInterface
interface IParent {
void Method1();
}
@FunctionalInterface
interface IParent1 extends IParent {
	default void Method2() {}
}
class Child implements IParent1
{

	@Override
	public void Method2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Method1() {
		// TODO Auto-generated method stub
		
	}
	


}


public class FunctionalInterfaceEx5 {
public static void main(String[] args) {
	
}
}
