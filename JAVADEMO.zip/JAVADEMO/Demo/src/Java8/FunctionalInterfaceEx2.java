package Java8;
@FunctionalInterface
interface ISample2{
	void Method1(int a,int b);
}


public class FunctionalInterfaceEx2 {
public static void main(String[] args) {
	ISample2 S=(a,b)->System.out.println("The value is a" + a+ " "+b);
	S.Method1(10,20);
	}
}



// ()->{.......};