package Java8;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import day12.Emp;

public class StreamEx1 {
public static void main(String[] args) {
	ArrayList<Integer>A=new ArrayList<Integer>();
	A.add(10);
	A.add(14);
	A.add(20);
	A.add(5);
	A.add(25);
	A.add(15);
	
	ArrayList<Emp> elist = new ArrayList<Emp>();
	Emp E = new Emp(1, "Ram", LocalDate.parse("2000-09-01"), 40000, 10);
	elist.add(E);
	E = new Emp(9, "Ramu", LocalDate.parse("2000-10-01"), 23000, 20);
	elist.add(E);
	E = new Emp(2, "Rahul", LocalDate.parse("2000-09-01"), 50000, 10);
	elist.add(E);
	E = new Emp(3, "James", LocalDate.parse("2001-08-01"), 60000, 30);
	elist.add(E);
	E = new Emp(4, "Ravi", LocalDate.parse("2002-10-24"), 70000, 10);
	elist.add(E);
	E = new Emp(5, "Scott", LocalDate.parse("1999-07-13"), 45000, 30);
	elist.add(E);
	E = new Emp(6, "Adams", LocalDate.parse("1998-03-01"), 20000, 10);
	elist.add(E);
	E = new Emp(7, "Rani", LocalDate.parse("2000-12-01"), 70000, 20);
	elist.add(E);
	E = new Emp(8, "Jones", LocalDate.parse("2001-11-01"), 25000, 10);
	elist.add(E);


	
	
Predicate<Integer>P= t-> {
		return t>=15;
	
};	
	
	A.stream().filter(P).forEach(s->System.out.println(s));
	System.out.println();
	A.stream().filter(t->{return t>=15;}).forEach(t->System.out.println(t));
	System.out.println();
	
	A.stream().filter(t->t>=15).forEach(s->System.out.println(s));
	List<Integer>L=A.stream().filter(t->t>=15).collect(Collectors.toList());
	L.forEach(s->System.out.println(s));





	//elist.stream().filter(t->t.getBasic()>=50000).forEach(e->System.out.println(e.Print()));

	List<Emp>list=  elist.stream().filter(t->t.getBasic()>=50000).collect(Collectors.toList());

	list.forEach(s->System.out.println(s.Print()));
	
	System.out.println();
	List<Emp>list1=  elist.stream().filter(t->t.getEname().startsWith("A")).collect(Collectors.toList());
	list1.forEach(s->System.out.println(s.Print()));
	list1.forEach(System.out::println);
	System.out.println();
	elist.stream().filter(t->t.getDob().compareTo(LocalDate.parse("2001-01-01"))>0).forEach(System.out::println);
	System.out.println();
	elist.stream().filter(t->Period.between(t.getDob(), LocalDate.now()).getYears()>=25).forEach(t->System.out.println(t));









}
}
