package Java8;

import java.util.function.BiFunction;

class Calculations
{
	public static float Addition(int a,int b)
	{
		return a+b+10.5f;
	}
	public static int Difference(int a,int b)
	{
		return a-b;
	}

}

public class MethodReferenceEx3 {
	public static void main(String[] args) {
	BiFunction<Integer, Integer, Float> B=Calculations::Addition;
	float output=B.apply(10, 20);
	System.out.println(output);	
	BiFunction<Integer, Integer, Integer> B1=Calculations::Difference;
	int output1=B1.apply(10, 20);
	System.out.println(output1);
	}
}
