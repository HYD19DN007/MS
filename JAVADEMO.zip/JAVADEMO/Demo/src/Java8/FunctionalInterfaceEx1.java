package Java8;
@FunctionalInterface
interface ISample{
	void Method1();
}


public class FunctionalInterfaceEx1 {
public static void main(String[] args) {
	ISample S=new ISample() {
		
		@Override
		public void Method1() {
			System.out.println("Method1");
		}
	};
	S.Method1();
}
}
