package Java8;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import day12.Emp;

public class CollectionsEx1 {
public static void main(String[] args) {
	ArrayList<Integer>A=new ArrayList<Integer>();
	A.add(10);
	A.add(14);
	A.add(20);
	A.add(5);
	A.add(25);
	A.add(15);

	Collections.sort(A);
	A.forEach(a->System.out.println(a));
	
	
	ArrayList<Emp> elist = new ArrayList<Emp>();
	Emp E = new Emp(1, "Ram", LocalDate.parse("2000-09-01"), 40000, 10);
	elist.add(E);
	E = new Emp(9, "Ramu", LocalDate.parse("2000-10-01"), 23000, 20);
	elist.add(E);
	E = new Emp(2, "Rahul", LocalDate.parse("2000-09-01"), 50000, 10);
	elist.add(E);
	E = new Emp(3, "James", LocalDate.parse("2001-08-01"), 60000, 30);
	elist.add(E);
	E = new Emp(4, "Ravi", LocalDate.parse("2002-10-24"), 70000, 10);
	elist.add(E);
	E = new Emp(5, "Scott", LocalDate.parse("1999-07-13"), 45000, 30);
	elist.add(E);
	E = new Emp(6, "Adams", LocalDate.parse("1998-03-01"), 20000, 10);
	elist.add(E);
	E = new Emp(7, "Rani", LocalDate.parse("2000-12-01"), 70000, 20);
	elist.add(E);
	E = new Emp(8, "Jones", LocalDate.parse("2001-11-01"), 25000, 10);
	elist.add(E);

	
	
	//Comparator<Emp>C=(o1,  o2) -> (int)(o1.getBasic()-o2.getBasic());
	
	
	
	
	
	
	
	
	Collections.sort(elist,(o1,  o2) -> (int)(o1.getBasic()-o2.getBasic()));
	elist.forEach(s->System.out.println(s.Print()));
	System.out.println();
	Collections.sort(elist,(o1,o2)->o1.getDob().compareTo(o2.getDob()));
	elist.forEach(s->System.out.println(s.Print()));
	System.out.println();
	Collections.sort(elist,(o1,o2)->o1.getEname().compareTo(o2.getEname()));
	elist.forEach(s->System.out.println(s.Print()));
	
	
	
	//Collections.sort(elist,(o1,o2)->);
	
	
	
}
}












