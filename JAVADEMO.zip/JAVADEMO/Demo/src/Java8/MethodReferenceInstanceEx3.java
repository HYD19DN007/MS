package Java8;

import java.util.function.BiFunction;

class Calculations1
{
	public  float Addition(int a,int b)
	{
		return a+b+10.5f;
	}
	public  int Difference(int a,int b)
	{
		return a-b;
	}

}

public class MethodReferenceInstanceEx3 {
	public static void main(String[] args) {
	Calculations1 C=new Calculations1();
	BiFunction<Integer, Integer, Float> B=C::Addition;
	float output=B.apply(10, 20);
	System.out.println(output);	
	BiFunction<Integer, Integer, Integer> B1=C::Difference;
	int output1=B1.apply(10, 20);
	System.out.println(output1);
	}
}
