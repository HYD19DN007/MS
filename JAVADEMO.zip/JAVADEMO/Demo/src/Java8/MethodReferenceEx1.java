package Java8;
//First way of referring static method withMethod reference.

interface IExample
{
	void Method1(int a,int b,int c,int d);
}


public class MethodReferenceEx1 {

	public static void RefMethod(int a,int b,int c,int d)
	{
		System.out.println("This is a refered Method"+ a+ " "+ b);
		
	}
	
	
	public static void main(String[] args) {
		
		IExample example=MethodReferenceEx1::RefMethod;
		example.Method1(10,20,30,40);
		}
}
