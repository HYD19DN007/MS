package Java8;
@FunctionalInterface
interface ISample3{
	int Method1(int a,int b);
}


public class FunctionalInterfaceEx3 {
public static void main(String[] args) {
	ISample3 S=(a,  b)-> a+b;
	System.out.println(S.Method1(10,20));
	}
}



