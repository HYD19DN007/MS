package Java8;
@FunctionalInterface
interface ISample4
{
	void Method1();

	
	default void Method2() 
	{
		System.out.println("Method2");
	}
	default void Method3() 
	{
		System.out.println("Method3");
	}
	static void Method4()
	{
		System.out.println("Method4");
	}
	static void Method5()
	{
		System.out.println("Method5");
	}
}

public class FunctionalInterfaceEx4 {

	public static void main(String[] args) {
		
		ISample4 S=()->System.out.println("Method1");	
			
			
	
		S.Method1();
		S.Method2();
		S.Method3();
		ISample4.Method4();
		ISample4.Method5();
		
	}
	
	
}
