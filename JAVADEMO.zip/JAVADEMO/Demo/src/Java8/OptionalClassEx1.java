package Java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

class Demo{
	int i,j;
	public Demo()
	{
		i=j=1;
	}
	public String Print()
	{
		return i + " "+j;
	}
}

public class OptionalClassEx1 {
public static void main(String[] args) {
String S[]=new String[10];
ArrayList<String>a=new ArrayList<String>();
//for (int i = 0; i < S.length; i++) {
//	S[i]="Hello";
//}

//String Str=S[5].toUpperCase();
String Sl;
Optional<String>  Str=Optional.ofNullable(S[5]);
if(Str.isEmpty())
{
	System.out.println("String is null");

}
else
{
	Sl=S[5].toUpperCase();
	System.out.println(Sl);
	
}	
Demo D[]=new Demo[3];
//D[2]=new Demo();
Optional<Demo> demo=Optional.ofNullable(D[2]);
if(demo.isPresent())
{
	System.out.println(D[2].Print());
}
else
{
	System.out.println("Demo object is null");
}

}
}
