package Java8;


class Sample1
{
	public static void RefMethod(int a,int b,int c)
	{
		System.out.println("This is a refered Method  I "+a+ " "+ b+ " "+c);
		
	}
	public static void RefMethod1(int a)
	{
		System.out.println("This is a refered Method  II  "+a);
		
	}
}

public class MethodReferenceIntanceEx2 {
	public static void main(String[] args) {
		
	Thread T=new Thread(()->Sample1.RefMethod(10,20,30));	
	T.start();
	Thread T1=new Thread(()->Sample1.RefMethod1(10));	
	T1.start();
	
	}
}
