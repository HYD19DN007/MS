package Java8;
interface ITest
{
 	void GetString(String str,String str1);
 	
}

class Test{
	
	Test(String str,String str1)
	{
		System.out.println("In Constructor "+str);
	}
}


public class MethodReferenceConst {
public static void main(String[] args) {
	
	ITest T=Test::new;
	T.GetString("Hello","Hi");
	
	
	
}
}
