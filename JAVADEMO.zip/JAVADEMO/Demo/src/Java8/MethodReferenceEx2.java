package Java8;


class Sample
{
	public  void RefMethod(int a,int b,int c)
	{
		System.out.println("This is a refered Method  I "+a+ " "+ b+ " "+c);
		
	}
	public  void RefMethod1(int a)
	{
		System.out.println("This is a refered Method  II  "+a);
		
	}
}

public class MethodReferenceEx2 {
	public static void main(String[] args) {
	
	Sample S=new Sample();
	Thread T=new Thread(()->S.RefMethod(10,20,30));	
	T.start();
	Thread T1=new Thread(()->S.RefMethod1(10));	
	T1.start();
	
	}
}
