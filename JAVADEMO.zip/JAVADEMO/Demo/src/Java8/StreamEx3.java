package Java8;

import java.util.ArrayList;
import java.util.Optional;
import java.util.function.BinaryOperator;

public class StreamEx3 {
public static void main(String[] args) {
	ArrayList<Integer>A=new ArrayList<Integer>();
	A.add(10);
	A.add(14);
	A.add(20);
	A.add(5);
	A.add(25);
	A.add(15);

	int sum=0;
	for(int i=0;i<A.size();i++)
	{
		sum=sum+A.get(i);
	}
	
	
	
	
	BinaryOperator<Integer>B=(t, u)-> 
			 t+u;
	
	
	Integer res=A.stream().reduce(0, (t,u)->t+u);
	System.out.println(res);
	Optional<Integer> res1=A.stream().reduce(B);
	System.out.println(res1.get());
}
}
