package Java8;
//First way of referring static method withMethod reference.

interface IExampleInstance
{
	void Method1(int a,int b,int c,int d);
	
}


public class MethodReferenceInstanceEx1 {

	public void RefMethod(int a,int b,int c,int d)
	{
		System.out.println("This is a refered Method"+ a+ " "+ b+ " "+ c + " "+d);
		
	}
	
	
	public static void main(String[] args) {
		
		MethodReferenceInstanceEx1 M=new MethodReferenceInstanceEx1();
		IExampleInstance IE=M::RefMethod;
		IE.Method1(10,20,30,40);
	
	}
}
