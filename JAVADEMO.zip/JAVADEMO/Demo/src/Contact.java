

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Contact {
private String name;
private String company;
private String title;
private String mobile, alternateMobile,email;
private LocalDate dateCreated;
public Contact() {
	super();
}

public Contact(String name, String company, String title, String mobile, String alternateMobile, String email,
		LocalDate dateCreated) {
	super();
	this.name = name;
	this.company = company;
	this.title = title;
	this.mobile = mobile;
	this.alternateMobile = alternateMobile;
	this.email = email;
	this.dateCreated = dateCreated;
}
public String getName() {
	return name;
}
public String getMobile() {
	return mobile;
}
public String getEmail() {
	return email;
}
DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MM-yyyy");
public String toString() {
	return "Name: "+name+"\n Company: "+ company+"\n Title: "+ title+" \n Mobile: "+mobile+"\n AlternateContact: "+ alternateMobile+"\n Email: "+email+"Date Created: "+ dateCreated.format(D);
	}
@Override
public boolean  equals(Object O) {
    Contact C = (Contact) O;
    if( name.equals(C.name) &&
           mobile.equals(C.mobile) &&
           email.equalsIgnoreCase(C.email))
    	return true;
    else 
    	return false;
    
}
}
