package day3;

import java.util.Scanner;

abstract class Employee {
	int empno;
	String ename;
	String dob;
	String email;
	String phone;

	// Default
	public Employee() {

	}

	// Parametrised accept the input
	public Employee(int empno, String ename, String dob, String email, String phone) {

		this.empno = empno;
		this.ename = ename;
		this.dob = dob;
		this.email = email;
		this.phone = phone;
	}

	public String Print() {
		String Str = "Empno " + empno + "\n";
		Str = Str + "Ename " + ename + "\n";
		Str = Str + "Dob " + dob + "\n";
		Str = Str + "Email " + email + "\n";
		Str = Str + "Phone " + phone + "\n";
		return Str;

	}

	public abstract double Calculate();

}

class Permanent extends Employee {

	String doj;
	double basic;

	public Permanent() {
		super();
	}

	public Permanent(int empno, String ename, String dob, String email, String phone, String doj, double basic) {
		super(empno, ename, dob, email, phone);
		this.doj = doj;
		this.basic = basic;
	}

	public String Print() {
		String Str = super.Print();
		Str = Str + "Doj " + doj + "\n";
		Str = Str + "Basic " + basic + "\n";
		return Str;
	}

	public double Calculate() {
		double hra = basic * 12 / 100;
		double vc = basic * 45 / 100;
		double tax = basic * 4 / 100;
		return basic + hra + vc - tax;

	}
}

class Contract extends Employee {
	String startdate;
	String enddate;
	double renumeration;

	public Contract() {
		super();
	}

	public Contract(int empno, String ename, String dob, String email, String phone, String startdate, String enddate,
			double renumeration) {
		super(empno, ename, dob, email, phone);
		this.startdate = startdate;
		this.enddate = enddate;
		this.renumeration = renumeration;
	}

	public String Print() {
		String Str = super.Print();
		Str = Str + "Start Date " + startdate + "\n";
		Str = Str + "End Date " + enddate + "\n";
		Str = Str + "Renum " + renumeration + "\n";
		return Str;
	}

	public double Calculate() {
		double tax = renumeration * 4 / 100;
		return renumeration - tax;
	}
}

public class InheritenceEx3 {
	public static void main(String[] args) {
		// Employee E=null;
//	Permanent P=new Permanent(2, "RAHUL", "01-OCt-2001", "rahul@gmail.com", "43434313","01-Oct-2024", 300000);
//	Contract C=new Contract(3, "JOHN", "01-Apr-2000", "john@gmail.com", "4343434a","02-Sep-2021", "01-Sep-2029", 30000);
//	
//	String S=P.Print();
//	System.out.println(S);
//	double amt=P.Calculate();
//	System.out.println(amt);
//	S=C.Print();
//	System.out.println(S);
//	amt=C.Calculate();
//	System.out.println(amt);
		System.out.println("Enter Employee type");
		Scanner S = new Scanner(System.in);
		Employee E = null;
		String etype = S.next();
		if (etype.equals("P"))
			E = new Permanent(2, "RAHUL", "01-OCt-2001", "rahul@gmail.com", "43434313", "01-Oct-2024", 300000);
		else

			E = new Contract(3, "JOHN", "01-Apr-2000", "john@gmail.com", "4343434a", "02-Sep-2021", "01-Sep-2029",
					30000);
		
		String Str=E.Print();
		System.out.println(Str);
		double amt =E.Calculate();
		System.out.println(amt);
		
		

	}
}
