package day3;
class Demo
{
	int a,b,c;
	static int d;
	public Demo(int a,int b,int c,int d)
	{
		this.a=a;
		this.b=b;
		this.c=c;
		this.d=d;
	}
	public static void display()
	{
		System.out.println(d);
	}
	
	public void print()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		display();
	}
	
}
public class StaticEx1 {
public static void main(String[] args) {
	Demo D=new Demo(1,2,3,4);
	D.print();
	
	Demo.display();
}
	
}
