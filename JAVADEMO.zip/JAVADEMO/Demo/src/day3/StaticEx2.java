package day3;

class Example {
	int a, b, c;
	static int d;
	static {
		d=10;
	print();
		System.out.println("Static block");
	}

	public Example() {
		a = 1;
		b = 2;
		c = 3;
		System.out.println("Default Constructor");
	}

	public static void print() {
		System.out.println("print");
	}

}

public class StaticEx2 {
	static 
	{
		System.out.println("static block of main class");
	}
		
	
	public static void main(String[] args) {
		Example.print();
//	Example.d=10;
//	Example E=new Example();
//	Example E2=new Example();
//	Example E3=new Example();
//	Example E4=new Example();
//	Example E5=new Example();
//	Example E6=new Example();
//	Example E7=new Example();

	}
}
