package day3;

public class Assignment1 {
public static void main(String[] args) {
	char ch[]= {'d','t','u','b','d',	'h',	'a',	't',	'a',	'u',	'a' };
	int a[]=new int[ch.length];
	int cnt=0;
	char chr=' ';
	for(int i=0;i<ch.length-1;i++)					
	{				
					
		if(a[i]==0)			
		{			
		chr=ch[i];			
		a[i]=1;	
		cnt=1;		
		for(int j=i+1;j<ch.length;j++)			
		{			
			if(chr==ch[j] && a[j]==0)		
			{		
				cnt++;	
				a[j]=1;
			}		
					
		}
		System.out.println(chr+ "-" +cnt);			
		}			
	}				

}
}
