package day3;
class Parent
{
	int a,b,c;
	public Parent()
	{
		a=1;
		b=1;
		c=1;
	}
	public Parent(int a)
	{
		this.a=a;
		this.b=a;
		this.c=a;
	}
	public Parent(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}
	

}
class Child extends Parent
{
	
	int l,m,n;
	public Child()
	{
		l=2;
		m=2;
		n=2;
	}
	public Child(int l, int m, int n,int o,int p,int q) {
		super(o,p,q);
		this.l = l;
		this.m = m;
		this.n = n;
	}
	public Child(int l,int m,int n,int o)
	{
		super(l);
		this.l=m;
		this.m=n;
		this.n=o;
				
	}

}


public class InheritenceEx2 {
public static void main(String[] args) {
	Parent P=new Parent();
	Child C=new Child();
	Parent P1=new Parent(10,20,30);
	Child C1=new Child(100,200,300,400,500,600);
	Child C2=new Child(100,200,300,400);
	System.out.println("P "+ P.a+ " "+ P.b+ " "+P.c);
	System.out.println("C "+ C.a+ " "+ C.b+ " "+C.c+ " "+C.l+ " "+C.m+ " "+C.n);
	System.out.println("P1 "+ P1.a+ " "+ P1.b+ " "+P1.c);
	
	System.out.println("C1 "+ C1.a+ " "+ C1.b+ " "+C1.c+ " "+C1.l+ " "+C1.m+ " "+C1.n);
	System.out.println("C2 "+ C2.a+ " "+ C2.b+ " "+C2.c+ " "+C2.l+ " "+C2.m+ " "+C2.n);
	
	
}
}
