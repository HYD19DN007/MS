package day3;

class Permanent1 {
	int empno;
	String ename;
	String dob;
	String doj;
	double basic;
	String email;
	String phone;

	public Permanent1(int empno, String ename, String dob, String doj, double basic, String email, String phone) {
		this.empno = empno;
		this.ename = ename;
		this.dob = dob;
		this.doj = doj;
		this.basic = basic;
		this.email = email;
		this.phone = phone;
	}
	public String Print()
	{
		String Str="Empno "+ empno+"\n";
		Str=Str +"Ename "+ ename+"\n";
		Str=Str +"dob "+ dob+"\n";
		Str=Str +"doj "+ doj+"\n";
		Str=Str +"Basic "+ basic+"\n";
		Str=Str +"Email "+ email+"\n";
		Str=Str +"phone "+ phone+"\n";
		return Str;
	}
}

class Contract1
{
	int empno;
	String ename;
	String dob;
	String email;
	String phone;
	String startdate;
	String enddate;
	double renumeration;
	
	public Contract1(int empno, String ename, String dob, String email, String phone, String startdate, String enddate,
			double renumeration) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.dob = dob;
		this.email = email;
		this.phone = phone;
		this.startdate = startdate;
		this.enddate = enddate;
		this.renumeration = renumeration;
	}
	
	
	public String Print()
	{
		String Str="Empno "+ empno+"\n";
		Str=Str +"Ename "+ ename+"\n";
		Str=Str +"dob "+ dob+"\n";
		Str=Str +"Email "+ email+"\n";
		Str=Str +"phone "+ phone+"\n";
		Str=Str +"Start Date "+ startdate+"\n";
		Str=Str +"End Date "+ enddate+"\n";
		Str=Str +"Renum "+ renumeration+"\n";
		
		return Str;
	}


}


public class InheritenceEx1 {
	public static void main(String[] args) {
		Permanent1 P=new Permanent1(1, "Manoj", "02-Feb-2000","05-Sep-2024" ,40000, "Manoj@techwave.com", "4545333");
		Contract1 C=new Contract1(2, "Mohan", "04-Oct-2000","Mohan@techwave.com", "4545433","01-Sep-2024", "01-Sep-2029", 50000);
		System.out.println(P.Print());
		System.out.println(C.Print());
	}
	
}
