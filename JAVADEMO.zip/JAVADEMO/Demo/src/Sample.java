import java.util.Scanner;

public class Sample {
public static void main(String[] args) {
	int a[]= new int[5];
	Scanner S=new Scanner(System.in);
	for (int i = 0; i < a.length; i++) {
		a[i]=S.nextInt();
	}
	int Sum=0;
	for(int i=0;i<5;i++)
	{
	Sum=Sum+a[i];

	}
System.out.println(Sum);
}
}
