package day4;

public class InheritanceEx4 {
public static void main(String[] args) {
	
}
}
