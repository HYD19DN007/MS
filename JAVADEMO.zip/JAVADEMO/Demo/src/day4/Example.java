package day4;
class Parent
{
	int a,b;
	public void method1()
	{
		System.out.println("method1 of parent");
	}
	public void method2()
	{
		System.out.println("method2 of parent");
	}

	
}
class Child extends Parent
{
	int c,d;
	@Override
	public void method1()
	{
		System.out.println("method1 of child");
	}
	public void method2()
	{
		System.out.println("method2 of Child");
	}
	public void method3()
	{
		System.out.println("method3 of child");
	}
	
}
class GrandChild extends Child
{
 int e,f;	
}

public class Example {
public static void main(String[] args) {
	Parent P=new Parent();
	P.method1();
	P.method2();
	System.out.println();
	Child C=new Child();
	C.method1();
	C.method2();
	C.method3();	
	System.out.println();
	Parent P1=new Child();// Run time polymorphims
	P1.method1();
	P1.method2();
	
	
}
}
