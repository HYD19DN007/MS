package day6;

public class Student {
	private int studentId;
	private String studentname;
	private String course;
	private double fees;
	private Address permanentAddress;
	
	public Student(int studentId, String studentname, String course, double fees, Address permanentAddress) {
		super();
		this.studentId = studentId;
		this.studentname = studentname;
		this.course = course;
		this.fees = fees;
		this.permanentAddress = permanentAddress;
		
	}
	public Student() {}

	public String Print()
	{
		String Str="Student Id"+ studentId + "\n";
		Str=Str+"Student Name "+studentname + "\n";
		Str=Str+"Course "+course+ "\n";
		Str=Str+"Fees "+fees+ "\n";
		Str=Str+ permanentAddress.Print();
		return Str;
		
	}

	
}
