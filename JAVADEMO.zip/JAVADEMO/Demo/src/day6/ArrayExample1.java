package day6;

import day5.Employee;

public class ArrayExample1 {
	public static void main(String[] args) {
		Employee E[] = { 
				new Employee(1, "AA", 35000), 
				new Employee(2, "BB", 40000), 
				new Employee(3, "CC", 25000),
				new Employee(4, "DD", 45000), 
				new Employee(5, "EE", 30000) };
		display(E);
		for (int i = 0; i < E.length; i++) {
			System.out.println(E[i].Print());
		}

	}

	public static void display(Employee A[]) {
		for (int i = 0; i < A.length; i++) {
			A[i].basic = A[i].basic + 2000;
		}

	}

}
