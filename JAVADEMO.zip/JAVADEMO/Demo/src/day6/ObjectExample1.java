package day6;

public class ObjectExample1 {
public static void main(String[] args) {
	String Str="1,RAM,Mtech,3000,12,xyz,New york,20013,NewYork,US";
	String Str2="2,RAMU,Btech,4000,10,abc,hyd,500080,TS,India";
	
	String s[]=Str.split(",");
	Address A=new Address(s[4],s[5],s[6],s[7],s[8],s[9]);
	Student S=new Student(Integer.parseInt(s[0]), s[1], s[2], Double.parseDouble(s[3]), A);
	System.out.println(S.Print());
//	System.out.println(S.studentId);
//	System.out.println(S.studentname);
//	System.out.println(S.course);
//	System.out.println(S.fees);
//	System.out.println(S.permanentAddress.hno);
//	System.out.println(S.permanentAddress.area);
//	System.out.println(S.permanentAddress.city);
//	System.out.println(S.permanentAddress.pincode);
//	System.out.println(S.permanentAddress.state);
//	System.out.println(S.permanentAddress.country);
//	
}
}
