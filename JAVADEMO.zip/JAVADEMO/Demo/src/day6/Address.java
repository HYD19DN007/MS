package day6;

public class Address {
	private String hno;
	private	String area;
	private String city;
	private String pincode;
	private String state;
	private String country;
	public Address() {
		super();
	}
	public Address(String hno, String area, String city, String pincode, String state, String country) {
		super();
		this.hno = hno;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
		this.country = country;
	}
	public String Print()
	{
		String Str="Hno "+hno+ "\n";
		Str=Str+"Area "+area+"\n";
		Str=Str+"city "+city+"\n";
		Str=Str+"Pincode "+pincode+"\n";
		Str=Str+"State "+state+"\n";
		Str=Str+"Country "+country+"\n";
		return Str;
	}

}
