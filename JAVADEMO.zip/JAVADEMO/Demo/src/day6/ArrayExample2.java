package day6;

import day5.Employee;

public class ArrayExample2 {
public static void main(String[] args) {
	Employee E[] = { 
			new Employee(1, "AA", 35000), 
			new Employee(2, "BB", 40000), 
			new Employee(3, "CC", 25000),
			new Employee(4, "DD", 45000), 
			new Employee(5, "EE", 30000) 
			};
	Sort(E);
	for(int i=0;i<E.length;i++)
	{
		System.out.println(E[i].Print());
	}
}
public static void Sort(Employee E[])
{
	for(int i=0;i<E.length-1;i++)
	{
		for(int j=i+1;j<E.length;j++)
		{
			if(E[i].basic>E[j].basic)
			{
			Employee temp;
			temp=E[i];
			E[i]=E[j];
			E[j]=temp;
			}
		}
		
	}


}


}
