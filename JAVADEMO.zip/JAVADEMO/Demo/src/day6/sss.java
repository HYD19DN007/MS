package day6;

public class sss {
public static void main(String[] args) {
	int a=10,b=20;
	Swap(a,b);
	System.out.println(a+ " "+b);
}
public static void Swap(int a, int b)
{
	int temp=a;
	a=b;
	b=temp;
	System.out.println(a+ " "+b);
}
}
