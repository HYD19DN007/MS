package day6;

public class ObjectExample2 {
	static Student student;

	public static void main(String[] args) {
		String Str = "1,RAM,Mtech,3000,12,xyz,New york,20013,NewYork,US";
		CreateStudent(Str);
		System.out.println(student.Print());
	}

	public static void CreateStudent(String Str) {
		String s[] = Str.split(",");
		Address A = new Address(s[4], s[5], s[6], s[7], s[8], s[9]);
		student = new Student(Integer.parseInt(s[0]), s[1], s[2], Double.parseDouble(s[3]), A);

	}

//	public static void Print() {
//		System.out.println(student.studentId);
//		System.out.println(student.studentname);
//		System.out.println(student.course);
//		System.out.println(student.fees);
//		System.out.println(student.permanentAddress.hno);
//		System.out.println(student.permanentAddress.area);
//		System.out.println(student.permanentAddress.city);
//		System.out.println(student.permanentAddress.pincode);
//		System.out.println(student.permanentAddress.state);
//		System.out.println(student.permanentAddress.country);
//
//	}

}
