package day6;

import java.util.Arrays;

import day5.Employee;

public class InheritenceEx8 
{
	public static void main(String[] args) 
	{

		Employee E[] = { 
				new Employee(1, "AA", 35000), 
				new Employee(2, "BB", 40000), 
				new Employee(3, "CC", 25000),
				new Employee(4, "DD", 45000), 
				new Employee(5, "EE", 30000) 
				};
		
			display(E,35000);
	}//End of main
	public static void display(Employee E[],double amt)
	{
	  for(int i=0;i<E.length;i++)
	  {
		  if(E[i].getBasic()>=amt)
		  System.out.println(E[i].Print());
	  }
	}

}
