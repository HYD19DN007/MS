////interface Sayable{  
////    void say();  
////}  
////public class MethodReference {  
////    public static void saySomething(){  
////        System.out.println("Hello, this is static method.");  
////    }  
////    public static void main(String[] args) {  
////        // Referring static method  
////        Sayable sayable = MethodReference::saySomething;  
////        // Calling interface method  
////        sayable.say();  
////    }  
////}  
//
//public class MethodReference {  
//    public static void ThreadStatus(){  
//        System.out.println("Thread is running...");  
//    }  
//    public static void main(String[] args) {  
//        Thread t2=new Thread(MethodReference::ThreadStatus);  
//        t2.start();       
//    }  
//}  



import java.util.function.BiFunction;  
class Arithmetic{  
public static float add(int a, int b){  
return a+b+0.5f;  
}  
}  
public class MethodReference {  
public static void main(String[] args) {  
BiFunction<Integer, Integer, Float>adder = Arithmetic::add;  
float result = adder.apply(10, 20);  
System.out.println(result);  
}  
}  