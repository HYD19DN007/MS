package day7;

abstract  class Parent {
	int a, b;
	static int c;
	public Parent() {}
	abstract public  void Method1();
	
	public void Method2()
	{
		System.out.println("Method2");
	}
	
	public abstract void Method3();
}
 
class Child extends Parent {
	int l,m;

	
	public void Method1() {
		System.out.println("Method1 in child");
	}
	public void Method3() {
		System.out.println("Method3 in child");
	}


}

public class InheritenceEx9 {
public static void main(String[] args) {

	Parent P=new Child();
	P.a=100;
	P.b=200;
	Parent.c=10;
	Child C=new Child();
	System.out.println(Child.c);
	System.out.println(C.a);
	System.out.println(C.b);
	P.Method1();
	P.Method2();
	P.Method3();
}
}
