package day7;
class Demo
{
int a,b,c;

public Demo(int a, int b, int c) {
	super();
	this.a = a;
	this.b = b;
	this.c = c;
}
public String Print()
{
return a+ " "+ b+ " "+c;	
}

}
public class Example {
public static void main(String[] args) {
	Demo D=new Demo(10,20,30);
	Demo D1=new Demo(100,200,300);
	System.out.println(D.Print());
	
}
}
