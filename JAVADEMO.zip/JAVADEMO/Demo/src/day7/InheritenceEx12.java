package day7;
 class BaseCls
{
	public final void Method1()
	{
		System.out.println("Method1");
	}
	
}
final class Derivedcls
{

	public void Method2()
	{
		System.out.println("Method2 of Derived ");
	}
}


public class InheritenceEx12 {
public static void main(String[] args) {
	BaseCls B=new BaseCls();
}
}
