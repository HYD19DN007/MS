package day7;
abstract class Transaction
{
	protected int accountno;
	protected String name;
	protected double balance;
	public Transaction(int accountno, String name,double balance) {
		super();
		this.accountno = accountno;
		this.name = name;
		this.balance=balance;
	}
	
	public abstract void Withdraw(double amt);
	public abstract void Deposit(double amt);
}

class SavingAccount extends Transaction
{
	private double minbal=1000;
	public SavingAccount(int accountno, String name,double balance)
	{
		super(accountno,name,balance);
		
	}

	@Override
	public void Withdraw(double amt) {
		// TODO Auto-generated method stub
		if(balance-amt>minbal)
			balance=balance-amt;
	
	}

	@Override
	public void Deposit(double amt) {
		balance=balance+amt;
	}
	
	
}
class CurrentAccount extends Transaction
{
	double overdraft=100000;
	public CurrentAccount(int accountno, String name,double balance)
	{
		super(accountno,name,balance);
		
	}

	@Override
	public void Withdraw(double amt) {
		if(balance-amt>-100000)
			balance=balance-amt;
			
		
	}

	@Override
	public void  Deposit(double amt) {
		// TODO Auto-generated method stub
		balance=balance+amt;
		
	}
	
}


public class InheritanceEx11 {
public static void main(String[] args) {
	Transaction T=new SavingAccount(10, "Manoj", 100000);
	T.Withdraw(20000);
	System.out.println(T.balance);
	T=new CurrentAccount(2, "abc", 200000);
	T.Withdraw(250000);
	System.out.println(T.balance);
	
	
}
}
