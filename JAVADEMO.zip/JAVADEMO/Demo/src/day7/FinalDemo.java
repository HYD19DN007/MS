package day7;
class Demo1
{
	int a,b;
	final int c;
	static int d;
	static final int e=10;
	
	public Demo1(int a, int b, int c,int d1) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
		d=d1;
		
	}
	void Method1()
	{
		a++;
		b++;
		//c++;
		d++;
		
	}
		
}


public class FinalDemo {
public static void main(String[] args) {
	Demo1 D=new Demo1(10,20,30,40);
	Demo1 D1=new Demo1(100,200,300,400);
	System.out.println(D.a+ " "+ D.b+ " "+D.c+ " "+D.d);
	System.out.println(D1.a+ " "+ D1.b+ " "+D1.c+ " "+D1.d);
}
}
