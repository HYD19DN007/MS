package day7;
abstract class Shape
{
	protected double dim1,dim2;
	
	
	public Shape(double dim1) {
		super();
		this.dim1 = dim1;
	}
	public Shape(double dim1, double dim2) {
		super();
		this.dim1 = dim1;
		this.dim2 = dim2;
	}
	public abstract double Area();
	
	public abstract double Perimeter();
	
}
class Rectangle extends Shape
{
	public Rectangle(double dim1,double dim2)
	{
		super(dim1,dim2);
	}
	public double Area()
	{
		return dim1*dim2;
	}
	public double Perimeter()
	{
		return 2*(dim1+dim2);
	}
}

class Square extends Shape
{
	public Square(double dim1)
	{
		super(dim1);
	}
	public double Area()
	{
		return dim1*dim1;
	}
	public double Perimeter()
	{
		return dim1*4;
	}
	
	
}




public class InheritanceEx10 {
public static void main(String[] args) {
Shape S=new Rectangle(10,20);

System.out.println(S.Area());
S=new Square(25);
System.out.println(S.Area());

}
}
