package day7;
class Test
{
	int a,b,c;

	public Test(int a, int b, int c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}
	@Override
	public String toString()
	{
		return a+ " "+ b+ " "+ c;
		
	}
	@Override
	public boolean equals(Object obj)
	{
		Test A=(Test) obj;
		if(a==A.a && b==A.b && c==A.c)
			return true;
		else
			return false;
	}
}



public class InheritanceEx12 {
public static void main(String[] args) {
	
	
	Test T=new Test(1,2,3);
	Test T1=new Test(1,2,3);
	if(T.equals(T1))
		System.out.println("Same");
	else
		System.out.println("Not Same");
	System.out.println(T);
	System.out.println(T1);
}
}
