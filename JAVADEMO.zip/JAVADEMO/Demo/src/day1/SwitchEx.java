package day1;

public class SwitchEx {
	public static void main(String[] args) {
		String ch = "Two";
		switch (ch) {
		case "One":
			System.out.println("You have choosen one");
			break;
		case "Two":
			System.out.println("Ypu have choosen two");
			break;
		case "Three":
		
			System.out.println("you have choosne three");
			break;
		default:
			System.out.println("wrong choice");
			break;
		}
		System.out.println();
		}
}
