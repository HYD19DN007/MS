package day1;

import java.util.Scanner;

public class WhileEx2 {
	public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	char ch='n';

	while(ch=='y')
	{
		System.out.println("Continue");
		System.out.println("Do you want to continue");
		ch=S.next().charAt(0);
		
	}
	
	do {
		System.out.println("Continue");
		System.out.println("Do you want to continue");
		ch=S.next().charAt(0);
		
	}while(ch=='y');
	
	
	
	}
}
