package day1;

public class ForEx {
public static void main(String[] args) {
	int i,j;
	for(i=0;i<=10;i++)
	{
		for(j=0;j<=5;j++)
		{
			System.out.println(i+ " "+ j);
		}
	}
}
}
