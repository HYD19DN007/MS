package day1;

public class Demo {

}
