package day1;

public class ArrayEx2 {
	public static void main(String[] args) {
		int a[] = { 10, 20, 15, 25, 50, 22, 54, 1, 56, 79 };
		int b = a[0];
		int temp;
		for (int i = 1; i < a.length; i++) {
			if (b < a[i]) {
				b = a[i];
			}
		}
		System.out.println("The highest value is " + b);
		for (int i = 0; i < a.length - 1; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] > a[j]) {
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;

				}
			}
		}
		
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}

	}
}
