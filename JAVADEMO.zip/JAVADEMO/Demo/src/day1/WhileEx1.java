package day1;

public class WhileEx1 {
public static void main(String[] args) {
	int i=0,j=0;
	while(i<=10)
	{
		j=0;
		while(j<=5)
		{
			System.out.println(i + " "+ j);
			j++;
		}
		i++;
	}
}
}
