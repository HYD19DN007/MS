package day1;

public class First {

public static void main(String[] args) {

	int a=10;
	long l=a;
	int b=(int)l;//Compile time error
	float f=10.5f;
	double d=f;
	float f1=(float)d;//Type casting
	
	System.out.println(l);
	System.out.println(b);
}
}
