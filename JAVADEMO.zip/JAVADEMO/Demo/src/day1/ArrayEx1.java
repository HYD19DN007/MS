package day1;

import java.util.Scanner;

public class ArrayEx1 {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	int a[]=new int[5];
	for (int i = 0; i < a.length; i++) {
		a[i]=S.nextInt();
	}
	
	
	for (int i = 0; i < a.length; i++) {
		System.out.println(a[i]);
	}
	
}
}
