package day1;

public class IfConditionEx {
	public static void main(String[] args) {
		int a = 89;
		if (a >= 100) {
			System.out.println("Excellent");
			System.out.println("Congrats");
		} else if (a >= 80) {
			System.out.println("Very good");
			System.out.println("Can try for 100");
		} else if (a >= 70) {
			System.out.println("Good");
			System.out.println("Can do better");
		} else {
			System.out.println("Not up to the mark");
			System.out.println("Better luck next time");
		}
	}
}
