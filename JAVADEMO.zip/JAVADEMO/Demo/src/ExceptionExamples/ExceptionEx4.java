package ExceptionExamples;

import java.util.Scanner;

public class ExceptionEx4 {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	double Basic=S.nextDouble();
	try
	{
		if(Basic<10000)
			throw new CustomException("BAsic must be greater than 10000");
		else
			System.out.println(Basic);
	}
	catch (CustomException e) {
		System.out.println(e.getMessage());
	}
	}
}
