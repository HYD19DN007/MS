package ExceptionExamples;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionEx1 {
	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.println("Enter");

		try {
			int a = S.nextInt();
			int b = S.nextInt();
			int c = a / b;
			System.out.println(c);
		}

		catch (ArithmeticException e) {
			System.out.println("Cannot enter 0 for 2nd number");
		} catch (InputMismatchException e) {
			System.out.println("Enter only numbers");
		} catch (Exception E) {
			System.out.println("error occured");
		}

		finally {
			System.out.println("Done ");
		}

	}
}
