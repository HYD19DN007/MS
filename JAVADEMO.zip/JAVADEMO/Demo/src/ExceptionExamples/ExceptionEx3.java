package ExceptionExamples;

import java.util.Scanner;

class CustomException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomException(String s) {
		super(s);
	}

}

public class ExceptionEx3 {
	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.println("Enter age");
		int age = S.nextInt();
		
		try {
		if(age>=21 && age<=58)
		{
			System.out.println("You are eligible");
		}
		else
		{
			throw new CustomException("Age should be between 21-58");
		}
		}
		catch(CustomException E)
		{
			System.out.println(E.getMessage());
		}
	}
	

}
