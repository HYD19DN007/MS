package ExceptionExamples;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionEx2 {
	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		try {

			int a = S.nextInt();
			int b = S.nextInt();
				int c = a / b;
				System.out.println(c);

			
		} catch (ArithmeticException E) {
			System.out.println("Cannot be zero");
		} catch (InputMismatchException E) {
			System.out.println("Enter only numbers");
		}

	}

}
