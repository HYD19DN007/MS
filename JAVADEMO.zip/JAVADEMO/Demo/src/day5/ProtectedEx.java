package day5;


class Child2 extends Parent2
{

	public Child2()
	{
		a=10;
		b=20;
		c=30;
	}
}

class NonChild {

	public NonChild()
	{
		Parent2 P=new Parent2();
		P.a=10;
		P.b=20;
		P.c=30;
	}
	
	
}

public class ProtectedEx {
	public static void main(String[] args) {
		Parent2 P = new Parent2();

	}

}
