package day5;

public class MainClas {
public static void main(String[] args) {
	ILogic S=null;
	S=new Admin(1, "AB", "Male", "Manager", 20000);
	
	System.out.println(S.Display());
	S=new TeachingStaff(1, "ss", "male", "cs", 2, 50000, 10000);
	System.out.println(S.Display());
	S=new HOD(1, "ss", "male", "cs", 2, 50000, 10000 ,10, "cs");
	System.out.println(S.Display());
}
}
