package day5;

class test extends Parent2 {
	int a, b;

	public test() {
		a = 10;
		System.out.println(a);
	}

	
}

public class Sample {
	public static void main(String[] args) {

	}
}
