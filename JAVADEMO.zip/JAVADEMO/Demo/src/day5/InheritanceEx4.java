package day5;
class Parent
{
	private int a,b,c;

	public Parent() {
		super();
		a=1;
		b=2;
		c=3;
	}

	public Parent(int a, int b, int c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}
	public String Print()
	{
		return a+ " "+ b+ " "+c;
	}
	
}



public class InheritanceEx4 {
public static void main(String[] args) {
	Parent P=new Parent();
	Parent P1=new Parent(10,20,30);
	
	System.out.println(P.Print());
	System.out.println(P1.Print());
	
	
	
}
}
