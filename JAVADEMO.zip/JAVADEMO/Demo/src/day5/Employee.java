package day5;

public class Employee {
	
	public int empno;
	public String ename;
	public double basic;
	public Employee() {
		super();
	}
	public Employee(int empno, String ename, double basic) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.basic = basic;
	}
	public String Print()
	{
		return "Empno " +empno + " Ename "+ename+ " basic "+basic;
	}
	public double getBasic()
	{
		return basic;
	}
	
}
