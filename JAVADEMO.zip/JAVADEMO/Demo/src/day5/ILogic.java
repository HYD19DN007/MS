package day5;

public interface ILogic {
String Display();
double Calculate();
}
