package day5;

import java.util.Scanner;

public class InheritenceEx7 {
public static void main(String[] args) {
	Scanner S=new Scanner(System.in);
	Employee E[]=new Employee[2];
	int eno;
	String en;
	double b;
	System.out.println("Enter values");
	for(int i=0;i<E.length;i++)
	{
		eno=S.nextInt();
		S.nextLine();
		en=S.nextLine();
		b=S.nextDouble();
		E[i]=new Employee(eno,en,b);
	}
	
	for (int i = 0; i < E.length; i++) {
		System.out.println(E[i].Print());
	}
}
}
