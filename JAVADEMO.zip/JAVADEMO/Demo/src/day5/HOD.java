package day5;

public class HOD extends TeachingStaff {
	private int deptId;
	private String deptName;

	public HOD(int staffId, String staffName, String gender, String subject, int exp, double basic,
			double teachingAllowance, int deptId, String deptName) {
		super(staffId, staffName, gender, subject, exp, basic, teachingAllowance);
		this.deptId = deptId;
		this.deptName = deptName;
	}

	public HOD() {
		super();
	}
	
	public String Display()
	{
		
		return super.Display()+"\nDeptid "+deptId+ "\nDeptName "+deptName;
	}
}
