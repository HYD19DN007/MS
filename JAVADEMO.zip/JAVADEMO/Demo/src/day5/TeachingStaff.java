package day5;

public class TeachingStaff extends Staff {
	private String subject;
	private int	exp;
	private double	basic;
	private double teachingAllowance;
	public TeachingStaff(int staffId, String staffName, String gender, String subject, int exp, double basic,
			double teachingAllowance) {
		super(staffId, staffName, gender);
		this.subject = subject;
		this.exp = exp;
		this.basic = basic;
		this.teachingAllowance = teachingAllowance;
	}
	public TeachingStaff() {
		super();
	}
	public double Calculate()
	{
		double HRA=basic*15/100;
		double DA=basic*60/100;
		double Gross= basic+HRA+DA+ teachingAllowance;
		return Gross;
	}
	public String Display()
	{
		String Str=super.Display();
		Str=Str+"\nsubject "+subject+ "\nexp "+ exp+ "\nbasic "+basic+"\nteaching Allowance"+ teachingAllowance+"\nGross"+Calculate();
		return Str;
	}
}
