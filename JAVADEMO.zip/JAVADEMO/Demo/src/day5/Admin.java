package day5;

public class Admin extends Staff 
{
	private String designation;
	private double basic;
	public Admin() {
		super();
	}
	public Admin(int staffId, String staffName, String gender, String designation, double basic) {
		super(staffId, staffName, gender);
		this.designation = designation;
		this.basic = basic;
	}
	
	public String Display()
	{
		return super.Display()+"\nDesignation "+designation+ "\nBasic "+basic + "\nGross "+Calculate();
	}
	
	public double Calculate()
	{
	 	double HRA=basic*10/100;
	 	double DA= basic*40/100;
	 	double Gross= basic+HRA+DA;
	 	return Gross;

	}

	
}
