package day5;

abstract public class Staff implements ILogic{
	private int staffId;
	private String staffName;
	private String gender;
	public Staff() {
		super();
	}
	public Staff(int staffId, String staffName, String gender) {
		super();
		this.staffId = staffId;
		this.staffName = staffName;
		this.gender = gender;
	} 
	public String Display()
	{
		return "StaffId " + staffId+ "\nStaff Name "+staffName+ "\nGender "+gender;
		
	}
	

}
