package day5;

public class Parent2 {
 public int a,b,c;

}
