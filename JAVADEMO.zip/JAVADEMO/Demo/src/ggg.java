@FunctionalInterface

interface Intf{
	void method(int x);
	
}

public class ggg {
public static void main(String[] args) {
Intf I=(int x) -> { x++; }	;

I.method(10);
}
}
