package com.gfg.addressap.repository;
import com.gfg.addressap.entity.Address;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AddressRepo extends JpaRepository<Address, Integer> {

    @Query(
        nativeQuery = true,
        value
        = "SELECT * FROM address ea where  ea.empno=:employeeno")
       Optional<Address> findAddressByEmpno(@Param("employeeno") int employeeno);
}