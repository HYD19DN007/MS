package com.gfg.addressap.response;

public class AddressResponse {

	 private int id;
	    private String city;
	    private String state;
	    private int empno;

	    public AddressResponse() {
			super();
		}

		public AddressResponse( String city, String state, int empno) {
			super();
			
			this.city = city;
			this.state = state;
			this.empno = empno;
		}

		public int getEmpno() {
			return empno;
		}

		public void setEmpno(int empno) {
			this.empno = empno;
		}

		public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    public String getCity() {
	        return city;
	    }

	    public void setCity(String city) {
	        this.city = city;
	    }

	    public String getState() {
	        return state;
	    }

	    public void setState(String state) {
	        this.state = state;
	    }
}