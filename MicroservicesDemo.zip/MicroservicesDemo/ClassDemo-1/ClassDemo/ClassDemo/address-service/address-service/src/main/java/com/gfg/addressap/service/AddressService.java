package com.gfg.addressap.service;

import com.gfg.addressap.entity.Address;
import com.gfg.addressap.repository.AddressRepo;
import com.gfg.addressap.response.AddressRequest;
import com.gfg.addressap.response.AddressResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AddressService {

    @Autowired
    private AddressRepo addressRepo;

    @Autowired
    private ModelMapper mapper;

    public AddressResponse findAddressByEmpno(int employeeno) {
    	System.out.println(employeeno);
        Optional<Address> addressByEmployeeId = addressRepo.findAddressByEmpno(employeeno);
        System.out.println(addressByEmployeeId.get());
        AddressResponse addressResponse = mapper.map(addressByEmployeeId, AddressResponse.class);
        return addressResponse;
    }

    public Boolean AddAddress(AddressRequest req)
    {
    	Address address=new Address();
    
    	address.setCity(req.getCity());
    	address.setState(req.getState());
    	address.setEmpno(req.getEmpno());
    	addressRepo.save(address);
    	return true;
    	
    }
}