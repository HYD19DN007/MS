package com.gfg.employeeap.service;

import java.util.Optional;
import java.util.OptionalInt;

import com.gfg.employeeap.entity.Employee;
import com.gfg.employeeap.feignclient.AddressClient;
import com.gfg.employeeap.repository.EmployeeRepo;
import com.gfg.employeeap.response.AddressRequest;
import com.gfg.employeeap.response.AddressResponse;
import com.gfg.employeeap.response.EmployeeRequest;
import com.gfg.employeeap.response.EmployeeResponse;



import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private ModelMapper mapper;
    
    @Autowired
    AddressClient addressClient;
    public EmployeeResponse getEmployeeById(int id) {

        Optional<Employee> employee = employeeRepo.findById(id);
        System.out.println(employee);
        EmployeeResponse employeeResponse = mapper.map(employee, EmployeeResponse.class);
        ResponseEntity<AddressResponse> addressResponse=addressClient.getAddressByEmpno(id);
        System.out.println("Address"+  addressResponse.getBody());
        
        employeeResponse.setAddressResponse(addressResponse.getBody());
        
        return employeeResponse;
    }
    
    public String Create(EmployeeRequest employeeRequest)
    {
    	Employee E=new Employee();
    	E.setName(employeeRequest.getName());
    	E.setEmail(employeeRequest.getEmail());
    	E.setAge(employeeRequest.getAge());
    	employeeRepo.save(E);
    	employeeRepo.findById(1).get();
    	int r=employeeRepo.findAll().stream().mapToInt(i->i.getId()).max().getAsInt();
    	System.out.println(r);
    	AddressRequest request=new AddressRequest();
    	request.setCity(employeeRequest.getAddressRequest().getCity());
    	request.setState(employeeRequest.getAddressRequest().getState());
    	request.setEmpno(r);
    	ResponseEntity<Boolean> b = addressClient.AddAddress(request);
    	if(b.getBody())
    		return "inserted";
    	else
    		return "error";
    
    }

       
}