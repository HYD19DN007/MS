package com.gfg.employeeap.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.gfg.employeeap.response.AddressRequest;
import com.gfg.employeeap.response.AddressResponse;

@FeignClient(name="address-service",url="http://localhost:8093",path="/address-service")
public interface AddressClient {
	
	@GetMapping("/address/{employeeno}")
		public ResponseEntity<AddressResponse> getAddressByEmpno(@PathVariable("employeeno") int employeeno);
	@PostMapping("/add")
		public ResponseEntity<Boolean> AddAddress(@RequestBody AddressRequest addressRequest);
	
	

}
