package com.gfg.employeeap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gfg.employeeap.response.EmployeeRequest;
import com.gfg.employeeap.response.EmployeeResponse;
import com.gfg.employeeap.service.EmployeeService;

@RestController
@RequestMapping("/employee-service")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/employees/{id}")
    private ResponseEntity<EmployeeResponse> getEmployeeDetails(@PathVariable("id") int id) {
        EmployeeResponse employee = employeeService.getEmployeeById(id);
        return ResponseEntity.status(HttpStatus.OK).body(employee);
    }
 @PostMapping("/create")
 public ResponseEntity<String> create(@RequestBody EmployeeRequest employeeRequest)
 {
	return ResponseEntity.status(HttpStatus.OK).body(employeeService.Create(employeeRequest)); 
 }
}