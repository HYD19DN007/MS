package com.gfg.employeeap.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.gfg.employeeap.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {
	
//	   @Query(
//		        nativeQuery = true,
//		        value
//		        = "SELECT * FROM address ea where  ea.empno=:employeeno")
//		       Optional<Address> findAddressByEmpno(@Param("employeeno") int employeeno);
	

}