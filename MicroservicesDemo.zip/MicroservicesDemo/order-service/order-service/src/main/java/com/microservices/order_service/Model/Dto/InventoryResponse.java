package com.microservices.order_service.Model.Dto;

public class InventoryResponse {
private String skuCode;
private boolean availabilty;
public InventoryResponse() {
	super();
}
public InventoryResponse(String skuCode, boolean availabilty) {
	super();
	this.skuCode = skuCode;
	this.availabilty = availabilty;
}
public boolean isAvailabilty() {
	return availabilty;
}
public void setAvailabilty(boolean availabilty) {
	this.availabilty = availabilty;
}
}
