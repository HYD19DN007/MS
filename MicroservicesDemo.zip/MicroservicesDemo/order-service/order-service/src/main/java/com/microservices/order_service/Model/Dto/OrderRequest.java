package com.microservices.order_service.Model.Dto;

import java.util.List;

public class OrderRequest {
private List<OrderItemsDto> orderItemsDtos;

public List<OrderItemsDto> getOrderItemsDtos() {
	return orderItemsDtos;
}

public void setOrderItemsDtos(List<OrderItemsDto> orderItemsDtos) {
	this.orderItemsDtos = orderItemsDtos;
}
public OrderRequest() {}
public OrderRequest(List<OrderItemsDto> orderItemsDtos) {
	super();
	this.orderItemsDtos = orderItemsDtos;
}

}
