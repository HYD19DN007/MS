package com.microservices.order_service.Model.Dao.ServiceImpl;

import java.net.URI;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.microservices.order_service.Model.Dao.Services.IOrder;
import com.microservices.order_service.Model.Dto.InventoryResponse;
import com.microservices.order_service.Model.Dto.OrderItemsDto;
import com.microservices.order_service.Model.Dto.OrderRequest;
import com.microservices.order_service.Model.Dto.OrderResponse;
import com.microservices.order_service.Model.Pojo.OrderItems;
import com.microservices.order_service.Model.Pojo.Orders;
import com.microservices.order_service.Model.Repositories.OrderRepository;

@Service
public class OrderServices implements IOrder {

	@Autowired
	OrderRepository orderRepository;
	@Autowired 
	WebClient.Builder webClientBuilder;
	
	@Override
	public void PlaceOrder(OrderRequest orderRequest) {
		Orders orders = new Orders();
		Random random = new Random();
		orders.setOrdernumber(String.valueOf(random.nextInt(1, 100000)));
		// orders.setOrdernumber(UUID.randomUUID().toString());
		orders.setOrderdate(LocalDate.now());
		orders.setOrderItemsList(orderRequest.getOrderItemsDtos().stream().map(this::mapToOrderItems).toList());
		List<String>slist=   orders.getOrderItemsList().stream().map(i->i.getSkuCode()).toList();
		System.out.println(slist);
		InventoryResponse[] inventoryResponse=  webClientBuilder.build().get().uri("http://inventory-service/api/inventory",u->u.queryParam("skuCodes", slist).build())
		.retrieve().bodyToMono(InventoryResponse[].class).block();
		// all the availability is true it will retrun true other wise return false
		Boolean B=Arrays.stream(inventoryResponse).allMatch(i->i.isAvailabilty());
		//http://localhost:8090/invertory?skuCodes=iphone-14&skuCodes=iphone15& 
		
		if(B)
				orderRepository.save(orders);
		else
			throw new IllegalArgumentException("Out of Stock");
	}

	
	
	
	
	
	public OrderItems mapToOrderItems(OrderItemsDto orderItemsDto) {
		return new OrderItems(orderItemsDto.getSkuCode(), orderItemsDto.getPrice(), orderItemsDto.getQuantity());
	}

	
	
	
	
	
	
	
	@Override
	public OrderResponse ViewOrderById(Long id) {
		// TODO Auto-generated method stub
	try {
		return mapToOrderResponse(orderRepository.findById(id).get());
	}
	catch(NoSuchElementException ex)
	{
		return null;
	}
	}

	
	
	@Override
	public List<OrderResponse> ViewOrders() {
		// TODO Auto-generated method stub
		return orderRepository.findAll().stream().map(this::mapToOrderResponse).toList();
	}
	
	
	public OrderResponse mapToOrderResponse(Orders order)
	{
		return new OrderResponse(order.getId(),order.getOrdernumber(),order.getOrderdate(),order.getOrderItemsList());
	}

}
