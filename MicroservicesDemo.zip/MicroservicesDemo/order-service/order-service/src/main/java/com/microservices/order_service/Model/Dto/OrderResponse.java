package com.microservices.order_service.Model.Dto;

import java.time.LocalDate;
import java.util.List;

import com.microservices.order_service.Model.Pojo.OrderItems;

public class OrderResponse {
	private Long id;
	private String ordernumber;
	private LocalDate orderdate;
	private List<OrderItems> orderItemsList;
	public OrderResponse() {
		super();
	}
	public OrderResponse(Long id, String ordernumber, LocalDate orderdate, List<OrderItems> orderItemsList) {
		super();
		this.id = id;
		this.ordernumber = ordernumber;
		this.orderdate = orderdate;
		this.orderItemsList = orderItemsList;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrdernumber() {
		return ordernumber;
	}

	public void setOrdernumber(String ordernumber) {
		this.ordernumber = ordernumber;
	}

	public LocalDate getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(LocalDate orderdate) {
		this.orderdate = orderdate;
	}

	public List<OrderItems> getOrderItemsList() {
		return orderItemsList;
	}

	public void setOrderItemsList(List<OrderItems> orderItemsList) {
		this.orderItemsList = orderItemsList;
	}

}
