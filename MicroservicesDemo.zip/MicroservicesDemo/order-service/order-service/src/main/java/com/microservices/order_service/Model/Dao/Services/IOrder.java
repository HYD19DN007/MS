package com.microservices.order_service.Model.Dao.Services;

import java.util.List;

import com.microservices.order_service.Model.Dto.OrderRequest;
import com.microservices.order_service.Model.Dto.OrderResponse;

public interface IOrder {
	void PlaceOrder(OrderRequest orderRequest);

	OrderResponse ViewOrderById(Long id);

	List<OrderResponse> ViewOrders();

}
