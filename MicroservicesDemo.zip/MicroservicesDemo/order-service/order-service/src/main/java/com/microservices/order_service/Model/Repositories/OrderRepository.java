package com.microservices.order_service.Model.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.microservices.order_service.Model.Pojo.Orders;

public interface OrderRepository extends JpaRepository<Orders, Long>{

}
