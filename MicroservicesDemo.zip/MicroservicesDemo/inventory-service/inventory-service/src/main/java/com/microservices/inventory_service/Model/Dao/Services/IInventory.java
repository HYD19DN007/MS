package com.microservices.inventory_service.Model.Dao.Services;

import java.util.List;

import com.microservices.inventory_service.Model.Dto.InventoryRequest;
import com.microservices.inventory_service.Model.Dto.InventoryResponse;

public interface IInventory {
public String Create(InventoryRequest request);
public List<InventoryResponse> InStock(List<String> skuCode);
}
	
