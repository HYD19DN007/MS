package com.microservices.inventory_service.Model.Dto;

public class InventoryRequest {
	private String skuCode;  
	private int quantity;
	public String getSkuCode() {
		return skuCode;
	}
	public void setSkuCode(String skuCode) {
		this.skuCode = skuCode;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public InventoryRequest(String skuCode, int quantity) {
		super();
		this.skuCode = skuCode;
		this.quantity = quantity;
	}
	public InventoryRequest() {
		super();
	}
	
}
