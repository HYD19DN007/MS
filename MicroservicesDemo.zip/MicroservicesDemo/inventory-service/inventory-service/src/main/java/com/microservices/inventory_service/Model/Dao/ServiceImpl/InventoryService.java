package com.microservices.inventory_service.Model.Dao.ServiceImpl;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservices.inventory_service.Model.Dao.Services.IInventory;
import com.microservices.inventory_service.Model.Dto.InventoryRequest;
import com.microservices.inventory_service.Model.Dto.InventoryResponse;
import com.microservices.inventory_service.Model.Pojo.Inventory;
import com.microservices.inventory_service.Model.Repositories.InventoryRepository;
@Service
public class InventoryService implements IInventory {

	@Autowired
	InventoryRepository inventoryRepository;
	@Override
	public String Create(InventoryRequest request) 
	{
		 inventoryRepository.save(maptoInventory(request));
		 return "Invetory added";
	}
	
	public Inventory maptoInventory(InventoryRequest req)
	{
		return new Inventory(req.getSkuCode(), req.getQuantity());
	}
	
	
	@Override
	public List<InventoryResponse> InStock(List<String> skuCodes) {
		
	return inventoryRepository.findBySkuCodeIn(skuCodes).stream()
			.map(i->maptoInventoryResponse(i.getSkuCode(), i.getQuantity()>0)).toList();
		
	}
	
	
	public InventoryResponse maptoInventoryResponse(String skuCode,boolean qty)
	{
		return new InventoryResponse(skuCode,qty);
	}
}
