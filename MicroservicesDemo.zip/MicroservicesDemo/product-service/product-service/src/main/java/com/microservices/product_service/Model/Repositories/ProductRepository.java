package com.microservices.product_service.Model.Repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microservices.product_service.Model.Pojo.Product;
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
}
