package com.microservices.product_service.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.product_service.Model.Dao.Services.IProduct;
import com.microservices.product_service.Model.Dto.ProductRequest;
import com.microservices.product_service.Model.Dto.ProductResponse;
import com.microservices.product_service.Model.Pojo.Product;

@RestController
@CrossOrigin
@RequestMapping("/api/product")
public class ProductController {

	@Autowired
	IProduct productService;

	@PostMapping("/create")
//@ResponseStatus(HttpStatus.CREATED)	
	public ResponseEntity<String> Create(@RequestBody ProductRequest productRequest) {
		return ResponseEntity.status(HttpStatus.CREATED).body(productService.CreateProduct(productRequest));
//		productService.CreateProduct(productRequest);
	}

	@GetMapping("/")
	public ResponseEntity<Object> getProducts() {
		List<ProductResponse> list = productService.GetProducts();
		if (list.size() == 0)
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("No Products found");
		else
			return ResponseEntity.of(Optional.of(list));
	}

	@GetMapping("/getProduct/{id}")
	public ResponseEntity<Object> getProduct(@RequestParam("id") Long id) {
		ProductResponse P = productService.GetProductById(id);
		if (P == null)
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("No Products found with id " + id);
		else
			return ResponseEntity.of(Optional.of(P));
	}
}
