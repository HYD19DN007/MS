package com.microservices.product_service.Model.Dao.Services;

import java.util.List;

import com.microservices.product_service.Model.Dto.ProductRequest;
import com.microservices.product_service.Model.Dto.ProductResponse;

public interface IProduct {
	String CreateProduct(ProductRequest P); 
	List<ProductResponse>GetProducts();
	ProductResponse GetProductById(Long id);
}
