package com.microservices.product_service.Model.Dao.ServiceImpl;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.microservices.product_service.Model.Dao.Services.IProduct;
import com.microservices.product_service.Model.Dto.ProductRequest;
import com.microservices.product_service.Model.Dto.ProductResponse;
import com.microservices.product_service.Model.Pojo.Product;
import com.microservices.product_service.Model.Repositories.ProductRepository;
@Service
public class ProductService implements IProduct 
{

	@Autowired
	ProductRepository productRepository;
	@Override
	public String CreateProduct(ProductRequest P) {
		// TODO Auto-generated method stub
		try {
		Product product=new Product(P.getName(), P.getDescription(), P.getPrice()); 
		productRepository.save(product);
		return "Product Added";
		}
		catch(DataIntegrityViolationException Ex)
		{
			return "Cannot have null for field";
		}
		}

	@Override
	public List<ProductResponse> GetProducts() {
		List<Product>plist=  productRepository.findAll();
		return plist.stream().map(this::mapToProductResponse).toList();
	}

	@Override
	public ProductResponse GetProductById(Long id) {
		try {
		Product P=productRepository.findById(id).get();
		return mapToProductResponse(P);
		}
		catch(NoSuchElementException Ex)
		{
			return null;
		}
		}
	
	private ProductResponse mapToProductResponse(Product product)
	{
		return new ProductResponse
				(product.getId(),
				 product.getName(),
				 product.getDescription(),
				 product.getPrice());
	}

}
