import { Component } from '@angular/core';
import { ParticipantsService } from '../../participants.service';
import { User } from '../../user';

@Component({
  selector: 'app-fetchby-id',
  imports: [],
  templateUrl: './fetchby-id.component.html',
  styleUrl: './fetchby-id.component.css'
})
export class FetchbyIdComponent {
  //user={} as User;
  user:User;
  constructor(private participantService:ParticipantsService){}
public FetchById(id:string)
{
this.participantService.getParticantById(id).subscribe(data=>{this.user=data});

}
}
