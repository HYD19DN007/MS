import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FetchbyIdComponent } from './fetchby-id.component';

describe('FetchbyIdComponent', () => {
  let component: FetchbyIdComponent;
  let fixture: ComponentFixture<FetchbyIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FetchbyIdComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FetchbyIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
