import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../../employee.service';

@Component({
  selector: 'app-third',
  imports: [CommonModule],
  templateUrl: './third.component.html',
  styleUrl: './third.component.css'
})
export class ThirdComponent {
  public employees:any=[];
  constructor(private E:EmployeeService)
  {
    this.employees=E.getEmployees();
  }
getEmps()
{
  this.E.getEmployees();
}
}
