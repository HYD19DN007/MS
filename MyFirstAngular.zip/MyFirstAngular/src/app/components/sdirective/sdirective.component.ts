import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../../employee.service';
@Component({
  selector: 'app-sdirective',
  imports: [CommonModule],
  templateUrl: './sdirective.component.html',
  styleUrl: './sdirective.component.css'
})
export class SdirectiveComponent {
public display:boolean=false;
public divVisible:boolean=true;
public a:number=4;
public names=["Manoj","Mohan","Sathkruth","Rohith","Preetham"];
public colors=["red","blue","green","yellow"]

public employees:any=[];
  constructor(private E:EmployeeService)
  {
    this.employees=E.getEmployees();
  }

public color="abc";
//@Input()  public PData:string="";
@Input("PData") public data:string="";
hideDiv()
{
  this.divVisible=false;
}
showDiv()
{
  this.divVisible=true;
}
@Output() public cEvent=new EventEmitter();//EventEmitter will allow us to send the data out of component.
public sendData(data:string)
{
this.cEvent.emit(data);
}
}
