import { Component } from '@angular/core';
import { User } from '../../user';
import { CommonModule } from '@angular/common';
import { ParticipantsService } from '../../participants.service';
import { Console } from 'console';

@Component({
  selector: 'app-fetch-details',
  imports: [CommonModule],
  templateUrl: './fetch-details.component.html',
  styleUrl: './fetch-details.component.css'
})
export class FetchDetailsComponent {
  users=[] as User[];
  //users:User[];
  constructor(private participantService:ParticipantsService){}
  fetchdata()
  {
    this.participantService.getParticipants().subscribe(data=>{this.users=data;});

  }
  
}
