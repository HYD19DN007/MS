import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { User } from '../../user';
import { ParticipantsService } from '../../participants.service';

@Component({
  selector: 'app-tdf',
  imports: [CommonModule,FormsModule],
  templateUrl: './tdf.component.html',
  styleUrl: './tdf.component.css'
})
export class TdfComponent {
constructor(private service:ParticipantsService){}
  public topics=["Java","Dotnet","Angular"];

 userModel = {} as User; // Empty object
 
str:string;
PrintData()
{
this.service.addParticipant(this.userModel).subscribe(i=>{this.str="inserted"})


}
public hasError:boolean=true;
validatetopic(topic:any)
{
if(topic=="-1")
  this.hasError=true;
else
  this.hasError=false;
}

}
