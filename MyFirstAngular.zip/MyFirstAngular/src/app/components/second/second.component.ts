import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms'


import { style } from '@angular/animations';
@Component({
  selector: 'app-second',
  imports: [CommonModule,FormsModule],
  templateUrl: './second.component.html',
  styleUrl: './second.component.css'
})
export class SecondComponent {
public status:boolean=false;
public myId:number=1000;
public successcolor="success";
public failurecolor="failure";
public hasError:boolean=true;
public isspecial=true;
public highlightcolor='orange';
public messageclasses=
{
"success":!this.hasError,
"failure":this.hasError,
"textspecial":this.isspecial
}
public titleStyles=
{
color:'violet',
fontstyle:'Italic',
fontsize:'large'
}
public name:string="Techwave";
public company:string="";
public getMessage()
{
  this.name="Microsoft"; 
}
public getCompany(cn:string)
{
this.company=cn;
}
public displayname:string="Techwave Consultancy"; 

public change()
{
  this.displayname=this.displayname.toUpperCase();
}

}
