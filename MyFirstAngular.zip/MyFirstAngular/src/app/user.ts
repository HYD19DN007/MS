export class User {
    constructor(
        public name:string,
        public email:string,
        public phone:number,
        public topic:string,
        public timepreference:string,
        public transport:boolean
    ){}
   // name:string;
    // email:string;
    // phone:number;
    // topic:string;
    // timepreference:string;
    // transport:boolean;
}
