import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,of } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class ParticipantsService {
private baseUrl="http://localhost:3000/participants";


  constructor(private httpClient:HttpClient) { }

  getParticipants():Observable<User[]>
  {
    return this.httpClient.get<User[]>(`${this.baseUrl}`);
  }
  getParticantById(id:string):Observable<User>
  {
    return this.httpClient.get<User>(`${this.baseUrl}/${id}`);
  }
 addParticipant(user:User):Observable<Object>
 {
  return this.httpClient.post(`${this.baseUrl}`,user);
  
 }
}
