import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Userlogin } from './userlogin';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoggedInService {
  private baseUrl="http://localhost:8081/auth/";
  constructor(private httpClient:HttpClient) { }
  
   Validate(userlogin:Userlogin):Observable<any>
   {
      return this.httpClient.post(this.baseUrl+"token",userlogin);
   }
  
  
  
  isAuthenticated()
  {
  const status=localStorage.getItem("IsLoggedIn");
  if(status=="false" || status==null)
    return false;
  else
    return true;
}
  isAdmin()
  {
    const r=localStorage.getItem("roles");
    if(r=="admin")
      return true;
    else
      return false;
  }
}
