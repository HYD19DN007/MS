import { CanMatchFn } from '@angular/router';
import { LoggedInService } from './logged-in.service';
import { inject } from '@angular/core';

export const adminauthGuard: CanMatchFn = (route, segments) => {
  const logged=inject(LoggedInService);
  if(logged.isAdmin())
    {
      return true;
    }
    else
    {
      return false;
    }
};
