import { Routes } from '@angular/router';
import { FetchDetailsComponent } from './components/fetch-details/fetch-details.component';
import { FetchbyIdComponent } from './components/fetchby-id/fetchby-id.component';
import { LoginComponent } from './login/login.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { authGuard } from './auth.guard';
import { EmployeeComponent } from './employee/employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { NoAccessComponent } from './no-access/no-access.component';
import { childGuard } from './child.guard';
import { deactivateGuard } from './deactivate.guard';
import { adminauthGuard } from './adminauth.guard';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component';
import { userauthGuard } from './userauth.guard';
import { ProductdetailsComponent } from './productdetails/productdetails.component';

export const routes: Routes = [
{path:"details",component:FetchDetailsComponent,canActivate:[authGuard]},
{path:"product",component:ProductdetailsComponent,canActivate:[authGuard]},

{path:"fetchById",component:FetchbyIdComponent,canActivate:[authGuard],canDeactivate:[deactivateGuard]},
{path:"login",component:LoginComponent},
{path:"noaccess",component:NoAccessComponent},
{path:"dashboard", component:AdmindashboardComponent,canMatch:[adminauthGuard]},
{path:"dashboard", component:UserdashboardComponent,canMatch:[userauthGuard]},


{path:"employee",component:EmployeeComponent,canActivate:[authGuard],canActivateChild:[childGuard],
children:[
{path:"addemp",component:AddEmployeeComponent},
{path:"updateemp",component:UpdateEmployeeComponent}
]
},
{path:'',redirectTo:"/login",pathMatch:'full'},//http://localhost:4200
{path:"**",component:PagenotfoundComponent},

];
