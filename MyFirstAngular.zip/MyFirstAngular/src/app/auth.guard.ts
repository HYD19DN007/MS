import { CanActivateFn, Router } from '@angular/router';
import { LoggedInService } from './logged-in.service';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (route, state) => {
const loggin=inject(LoggedInService);
const router=inject(Router);  
if(loggin.isAuthenticated())
  return true;
else
{
  alert("Please login ");
  router.navigate(['login']);
  return false;
}
};
