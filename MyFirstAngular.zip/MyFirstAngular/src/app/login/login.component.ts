import { Component } from '@angular/core';
import { LoggedInService } from '../logged-in.service';
import { Userlogin } from '../userlogin';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  login={} as Userlogin;
  constructor(private service:LoggedInService,private router:Router){}
   Validate()
   {
      this.service.Validate(this.login).subscribe({next:(data)=>{
              localStorage.setItem("token",data.token);
              localStorage.setItem("roles",data.roles);
              localStorage.setItem("IsLoggedIn","true");
              console.log(localStorage.getItem("token"));
              console.log(localStorage.getItem("roles"));
              this.router.navigate(["/dashboard"]);              
        },
        error: (e)=>{
          console.log("Hello");  
          localStorage.setItem("IsLoggedIn","false");
          alert(e.error.Error);
          }}
      );
  
    }

}
