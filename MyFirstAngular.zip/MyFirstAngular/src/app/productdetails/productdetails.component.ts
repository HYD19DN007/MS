import { Component } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-productdetails',
  imports: [CommonModule],
  templateUrl: './productdetails.component.html',
  styleUrl: './productdetails.component.css'
})
export class ProductdetailsComponent {
products=[] as Product[];
constructor(private productservice:ProductService){}
getProducts()
{
  this.productservice.getproducts().subscribe(data=>{this.products=data;});
}
}
