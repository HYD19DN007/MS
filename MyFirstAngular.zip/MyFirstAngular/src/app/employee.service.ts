import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }
  public getEmployees()
  {
    return [
      {"id":1,"name":"manoj","age":22},
      {"id":2,"name":"mahan","age":23},
      {"id":3,"name":"preetham","age":21},
      ];
  }
}
