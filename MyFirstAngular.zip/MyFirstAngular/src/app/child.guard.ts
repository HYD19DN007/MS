import { CanActivateChildFn, Router } from '@angular/router';
import { LoggedInService } from './logged-in.service';
import { inject } from '@angular/core';


export const childGuard: CanActivateChildFn = (childRoute, state) => {
  const loggin=inject(LoggedInService);
  const router=inject(Router);
  console.log(loggin.isAdmin());
  if(loggin.isAdmin())
    return true;
  else 
  {
    alert("Only Admin can access");
    router.navigate(['noaccess']);
    return false;
  }
  };
