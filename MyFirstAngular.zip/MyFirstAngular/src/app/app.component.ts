import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { SecondComponent } from "./components/second/second.component";
import { SdirectiveComponent } from "./components/sdirective/sdirective.component";
import { ThirdComponent } from "./components/third/third.component";
import { TdfComponent } from "./components/tdf/tdf.component";
import { FetchDetailsComponent } from "./components/fetch-details/fetch-details.component";
import { FetchbyIdComponent } from "./components/fetchby-id/fetchby-id.component";
import { LoginComponent } from './login/login.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { EmployeeComponent } from './employee/employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { NoAccessComponent } from './no-access/no-access.component';
import { LoggedInService } from './logged-in.service';
import { routes } from './app.routes';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterLink, RouterOutlet,CommonModule, FetchDetailsComponent, FetchbyIdComponent, TdfComponent,LoginComponent,PagenotfoundComponent,EmployeeComponent,AddEmployeeComponent,UpdateEmployeeComponent,NoAccessComponent],
  templateUrl:'./app.component.html',
  styleUrls:['./app.component.css']
})
    

export class AppComponent {
  public firstname:string="Consultancy";
  public rollno:number;
  public message="Welcome to Techwave";
  currentDate:Date=new Date();
  isActive:boolean=true;
  public msg="";
  employee:any;
 // loc:string=window.location.href;
  constructor(private logged:LoggedInService,private router:Router)
  {
  //  this.firstname="Techwave";
    this.rollno=100;

  }
  getMethod()
  {
    let fn=this.firstname.toUpperCase();
    return fn;
  }

  isAuthenticated()
  {
    return this.logged.isAuthenticated();
  }
  Logout()
  {
    localStorage.removeItem("token");
    localStorage.setItem("IsLoggedIn","false");
    this.router.navigate(['/login'])
    
  }
}
