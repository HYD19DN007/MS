export class Product {
constructor(
    public id:number,
    public name:string,
    public description:number,
    public price:number

){}

}
