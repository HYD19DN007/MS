import { Component } from '@angular/core';

@Component({
  selector: 'app-admindashboard',
  imports: [],
  templateUrl: './admindashboard.component.html',
  styleUrl: './admindashboard.component.css'
})
export class AdmindashboardComponent {

}
