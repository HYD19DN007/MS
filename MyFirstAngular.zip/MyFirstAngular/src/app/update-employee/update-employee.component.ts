import { Component } from '@angular/core';

@Component({
  selector: 'app-update-employee',
  imports: [],
  templateUrl: './update-employee.component.html',
  styleUrl: './update-employee.component.css'
})
export class UpdateEmployeeComponent {

}
