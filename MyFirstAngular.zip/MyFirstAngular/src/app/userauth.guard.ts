import { CanMatchFn } from '@angular/router';
import { LoggedInService } from './logged-in.service';
import { inject } from '@angular/core';

export const userauthGuard: CanMatchFn = (route, segments) => {
  const loggin=inject(LoggedInService);
  if(loggin.isAdmin())
    return false;
  else
    return true;

};
