import { Component } from '@angular/core';

@Component({
  selector: 'app-userdashboard',
  imports: [],
  templateUrl: './userdashboard.component.html',
  styleUrl: './userdashboard.component.css'
})
export class UserdashboardComponent {

}
